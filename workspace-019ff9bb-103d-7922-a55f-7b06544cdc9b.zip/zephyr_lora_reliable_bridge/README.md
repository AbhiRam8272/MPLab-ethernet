# LoRa Reliable MAVLink Bridge — Zephyr RTOS Port

**Target:** Nucleo-WL55JC1 × 2 (STM32WL55JC1, **integrated LoRa transceiver**)
**PHY:** LoRa SF5, 125 kHz BW, CR 4/6 → **13,020 bps** (≈ your 13.12 kbps target)
**Link:** P2P LoRa, half-duplex, bidirectional UART ↔ LoRa bridge
**Goal:** 5-7 km NLOS, zero MAVLink frame loss
**Zephyr:** 3.x

---

## Table of Contents

1. [Why LoRa (not FSK) for this project](#why-lora-not-fsk-for-this-project)
2. [LoRa PHY configuration for 13.12 kbps](#lora-phy-configuration-for-1312-kbps)
3. [Zero-loss strategy (software-only, no hardware changes)](#zero-loss-strategy-software-only-no-hardware-changes)
4. [Link budget reality check](#link-budget-reality-check)
5. [Project structure](#project-structure)
6. [Build & flash](#build--flash)
7. [Node configuration](#node-configuration)
8. [Validation with Python logger](#validation-with-python-logger)
9. [Troubleshooting](#troubleshooting)
10. [Limitations & when this won't work](#limitations--when-this-wont-work)

---

## Why LoRa (not FSK) for this project

Your Nucleo-WL55JC1 has the **STM32WL55** chip, which includes an integrated Sub-GHz transceiver that supports **LoRa® , (G)FSK, (G)MSK, and BPSK** modulations [1]. This is fundamentally different from the STM32WLE5 (which is FSK-only).

| Property | FSK @ 13.12 kbps | LoRa SF5 @ 13.02 kbps |
|---|---|---|
| **RX sensitivity** | −113 to −123 dBm (depends on BW, datarate) | **−122 to −125 dBm** (typical for SF5 125 kHz) |
| **Processing gain** | None (narrowband) | **~15 dB** (processing gain from chirp spreading) |
| **Below-noise operation** | No — must be above noise floor | **Yes** — can receive signals below the noise floor |
| **Multipath resilience** | Poor (flat fade drops entire signal) | Better (chirp resists flat fades) |
| **NLOS performance** | Moderate | **Significantly better** |
| **Regulatory status** | Fine | Fine (LoRa is unlicensed, same bands as FSK) |
| **TX power** | +22 dBm (same) | +22 dBm (same) |

**The 12-15 dB sensitivity advantage of LoRa over FSK at the same data rate is the key physics benefit.** This comes from LoRa's chirp spread spectrum (CSS) modulation, which uses:

1. **Processing gain** = 10·log₁₀(2^SF) = 10·log₁₀(2^5) = **15 dB** at SF5
2. **Below-noise reception**: the receiver correlates the chirped signal, effectively integrating energy over the symbol period, allowing reception below the noise floor
3. **Resilience to multipath**: the chirp's frequency sweep over time provides diversity against flat fading

This is why LoRa is used for exactly your use case — long-range telemetry, rural links, NLOS monitoring — at distances of 5-15 km.

---

## LoRa PHY configuration for 13.12 kbps

Your target is 13.12 kbps. The LoRa bit rate formula is:

```
Rb = SF × (BW / 2^SF) × (4 / (4 + CR_index))
```

Where CR_index: 1=4/5, 2=4/6, 3=4/7, 4=4/8.

**For SF5, BW=125 kHz:**

| CR | Rb (bps) | Notes |
|---|---|---|
| 4/5 (CR=1) | 15,625 | Too fast — exceeds 13.12 kbps target |
| **4/6 (CR=2)** | **13,020** | **Closest to 13.12 kbps — only 0.8% below** |
| 4/7 (CR=3) | 11,161 | Too slow |
| 4/8 (CR=4) | 9,766 | Too slow |

**→ We use SF5, BW=125 kHz, CR 4/6 → 13,020 bps.** This is the closest LoRa mode to your 13.12 kbps FSK target, with a 15 dB processing gain and the same TX power (+22 dBm).

**LoRa airtime for a 40-byte payload at SF5, 125 kHz, CR 4/6:**

```
T_packet ≈ preamble_symbols × 2^SF / BW + payload_symbols × 2^SF / BW
         ≈ 8 × 32 / 125000 + (payload_symbols) × 32 / 125000
```

For a 40-byte (320-bit) payload with CR 4/6:
- Number of payload symbols ≈ 8 + max(8, ceil((8×320−4×5+28+16×2−20)/(4×(5−2×(4−4/6))))) 
- Roughly: ~45-50 symbols for payload
- Total airtime ≈ (8 + 48) × 32 / 125000 ≈ **13.9 ms**

At 13.02 kbps air rate, you can send ~72 packets/second theoretically, but LoRa's long airtime per packet (compared to FSK) means the practical limit is lower. For our MAVLink frames averaging 35 bytes, airtime is ~12-14 ms, giving ~70 pkt/s theoretical, ~50-60 pkt/s practical.

**This is close to your current 47 pkt/s at 13.12 kbps FSK.**

---

## Zero-loss strategy (software-only, no hardware changes)

Since you can't modify hardware (same Nucleo boards, same PCB antennas, same +22 dBm internal PA), the zero-loss strategy relies entirely on **software techniques**:

### 1. ARQ (Automatic Repeat reQuest) — the primary mechanism for zero loss

ARQ guarantees delivery by retransmitting lost frames. It's the same principle as TCP's reliability, applied to the MAVLink-over-LoRa link.

**ARQ protocol (half-duplex, batch-based):**

```
TX Node (drone/airborne):
  1. Collect MAVLink frames into an ARQ batch (batch_size = 8 default)
  2. Assign each frame a 16-bit sequence number (monotonic across all batches)
  3. Build LoRa packets (MAC header 8 bytes + MAVLink payload 21-43 bytes)
  4. TX batch packets one by one (half-duplex: TX, wait TxDone, TX next)
  5. After batch TX'd: switch to RX mode, listen for ACK from RX node
  6. ACK contains: last cumulative received frame sequence number
  7. Frames with seq > ACK are unacknowledged → retransmit in next batch
  8. If no ACK within ACK_TIMEOUT (300 ms default): retransmit unacked

RX Node (ground station):
  1. Continuous RX mode: listen for TX batch
  2. For each packet received:
     - Validate MAC header (node IDs match this node)
     - Validate LoRa CRC (done by modem)
     - Parse MAC header: get frame sequence number
     - If seq is new (> last delivered): deliver MAVLink payload to UART
     - Track expected next sequence (detect gaps = missing frames)
  3. After batch complete (RX timeout or batch_size reached):
     - Build ACK: cumulative last received seq
     - TX ACK packet over LoRa
  4. Switch back to RX mode for next batch
```

**Why ARQ guarantees zero loss:**
- Every MAVLink frame gets a sequence number
- The RX confirms receipt via ACK
- Unacknowledged frames are retransmitted until ACK'd (up to MAX_RETRIES)
- Duplicates are detected and dropped (seq ≤ last_delivered)
- The Python logger on the RX side sees a complete, ordered MAVLink stream

**ARQ cost:**
- Retransmission airtime: if raw FER is 5%, ARQ adds ~5% overhead → effective throughput drops 5%
- If raw FER is 20%, ARQ adds ~20% overhead → throughput drops 20%
- **But delivery is 100%** (every frame eventually ACK'd)

**ARQ batch size tradeoff:**
- Larger batch (16 frames): fewer turnarounds, higher throughput, more retransmission waste when loss occurs
- Smaller batch (4 frames): more turnarounds, lower throughput, less waste
- Default 8: balances throughput (~30-40 pkt/s effective) with efficiency

### 2. MAC-layer sequence tracking + CRC (already in your code)

Your existing code has:
- **Per-packet sequence numbers** (16-bit, wraps) — detects duplicates, gaps
- **CRC checking** (LoRa modem's internal CRC + MAVLink's X.25 CRC) — detects corruption

These are preserved in the Zephyr port and form the foundation for ARQ.

### 3. RSSI/SNR monitoring (diagnostics, not loss prevention)

The LoRa modem reports RSSI and SNR per packet. We log these to:
- Understand link quality over time
- Detect when the link is degrading (SNR dropping)
- Correlate delivery failures with signal quality

This doesn't prevent loss, but it tells you **when** and **why** loss occurs, which is critical for debugging and for knowing if the link is operating near its margin.

### 4. Duplicate suppression (already in your code)

Your `ProcessRxPacket()` already detects and drops duplicates (seq ≤ last_rx_sequence). This is preserved and ensures the Python logger sees a clean, non-duplicated MAVLink stream.

### 5. Forward Error Correction (FEC) — optional, LoRa modem provides it

The LoRa modem has **built-in FEC** via the coding rate (CR 4/6 in our config). CR 4/6 means 6 bits transmitted for every 4 bits of payload — a 50% overhead that provides forward error correction capability. This is in addition to the implicit redundancy from chirp spreading.

For our purposes, the LoRa modem's CR 4/6 FEC is the FEC layer. We don't add application-layer FEC because:
- The LoRa FEC already provides significant error correction
- Adding more FEC would reduce effective throughput below 13.12 kbps
- ARQ handles the residual errors

### Summary: the software zero-loss stack

| Layer | Mechanism | Purpose |
|---|---|---|
| PHY (LoRa) | SF5, 125 kHz, CR 4/6, +22 dBm | 12-15 dB sensitivity advantage over FSK |
| LoRa modem | Built-in CRC + FEC (CR 4/6) | Detects and corrects bit errors within a packet |
| MAC | 16-bit sequence numbers, MAC CRC | Detects duplicates, gaps, corrupted frames |
| ARQ | ACK/retry, selective repeat, max retries | **Guarantees zero loss** by retransmitting lost frames |
| MAVLink | X.25 CRC, 8-bit sequence | Application-layer integrity check |
| Diagnostics | RSSI/SNR logging | Monitor link quality, debug loss events |

---

## Link budget reality check

**Given your constraints: India (866 MHz ISM), +22 dBm internal PA, stock Nucleo PCB antennas (~0 dBi both ends), NLOS 5-7 km, 13 kbps, zero loss required.**

### Path loss estimates:

```
Free-space path loss at 866 MHz:
  5 km:  20×log10(5000) + 20×log10(866e6) - 147.55 = 105.3 dB
  7 km:  20×log10(7000) + 20×log10(866e6) - 147.55 = 108.9 dB

NLOS additional loss (highly variable):
  Light NLOS (rural, trees, gentle hills): +15 to +25 dB
  Moderate NLOS (suburban, houses, gardens): +25 to +35 dB
  Heavy NLOS (urban, buildings, dense foliage): +35 to +50+ dB
```

### Received power and margin:

```
TX power     = +22 dBm
TX antenna   = 0 dBi (PCB antenna on Nucleo)
RX antenna   = 0 dBi (PCB antenna on Nucleo)

Scenario: 7 km, moderate NLOS (total path loss ≈ 140 dB)
  RX power = 22 + 0 + 0 - 140 = -118 dBm

LoRa SF5 sensitivity @ CR 4/6 (125 kHz BW):
  Typical: -122 to -125 dBm (depends on implementation, SNR threshold)

Margin = -118 - (-123) = +5 dB  (TIGHT, marginal for zero raw loss)
```

### What this means:

- **At 5 km NLOS (light):** RX power ≈ −108 dBm, margin ≈ +15 dB → raw delivery likely 95-99%. ARQ handles the 1-5% loss → **100% delivered**.
- **At 7 km NLOS (moderate):** RX power ≈ −118 dBm, margin ≈ +5 dB → raw delivery ~85-95%. ARQ handles 5-15% loss → **100% delivered, but throughput drops 5-15%**.
- **At 7 km NLOS (heavy/urban):** RX power ≈ −128 dBm, margin ≈ −5 dB → raw delivery 50-70%. ARQ handles the loss but throughput drops 30-50%. **This is the limit of stock hardware at 13 kbps.**

**The honest takeaway:**
- **5 km NLOS: achievable with zero loss** using LoRa SF5 + ARQ, even with stock hardware. Acceptable throughput hit (1-5%).
- **7 km NLOS (light-moderate): achievable with zero loss**, but throughput may drop 5-15% due to ARQ retransmissions. The link is operating near its margin.
- **7 km NLOS (heavy urban): unlikely to achieve zero loss at 13 kbps** with stock hardware. The physics of 13 kbps chirp at 866 MHz through buildings/foliage at 7 km is marginal. You'd need hardware improvements (better antenna, external PA, lower frequency).

If your NLOS conditions are **light** (open countryside, trees but no buildings, gentle terrain), the LoRa SF5 + ARQ approach should work for 5-7 km with zero loss and acceptable throughput. If your NLOS conditions are **heavy** (urban, buildings, dense foliage), you may need to either:
- Accept a lower data rate (higher SF, e.g., SF7-SF9, lower kbps) for better sensitivity
- Or add hardware improvements (external PA, high-gain antenna)

---

## Project structure

```
zephyr_lora_reliable_bridge/
├── README.md                       # This file
├── README_LINK_BUDGET.md          # Detailed link budget analysis
├── project.conf                    # Zephyr application configuration
├── CMakeLists.txt                  # Build file (STM32CubeWL integration)
├── Kconfig                         # Tunable parameters
├── lora_reliable_bridge.overlay    # Device tree overlay (UART2, LoRa GPIOs)
├── include/
│   ├── lora_reliable_bridge.h      # Public API header
│   └── lora_phy.h                  # LoRa PHY abstraction header
└── src/
    ├── main.c                      # Zephyr entry point + HAL init + thread creation
    ├── lora_phy.c                  # LoRa PHY wrapper (STM32CubeWL LoRa API)
    ├── mac_layer.c                 # MAC frame builder/parser
    ├── arq_manager.c               # ARQ state machine (ACK/retry)
    ├── bridge_app.c                # Top-level bridge (UART↔MAVLink↔ARQ↔LoRa)
    ├── uart_dma.c                  # UART2 DMA circular buffer (from your FSK code)
    └── diagnostics.c               # Counters, RSSI/SNR logging
```

---

## Build & flash

```bash
# Prerequisites: Zephyr SDK, west, Python 3.x

# 1. Build for Nucleo-WL55JC1
cd zephyr_lora_reliable_bridge
west build -b nucleo_wl55jc1 --clean

# 2. Flash
west flash

# 3. For Node B (ground station), rebuild with different node IDs:
#   In project.conf or via Kconfig:
#     CONFIG_THIS_NODE_ID=2  CONFIG_TARGET_NODE_ID=1
```

### STM32CubeWL HAL integration

This project uses the **STM32CubeWL HAL's LoRa API** (Radio_* calls with `MODDEM_LORA`), the same package you're already using for your FSK code.

To integrate:
1. Add the STM32CubeWL firmware package to your Zephyr project as source files
2. Include `STM32CubeWL/RF/inc/` and `STM32CubeWL/Utilities/inc/` in the include paths
3. Add the LoRa-related source files from `STM32CubeWL/RF/src/` and the HAL sources
4. Ensure the STM32CubeWL init sequence (HAL_Init, SystemClock_Config, MX_GPIO_Init, MX_RADIO_Init, Radio.Init) is called before `main()`

If you prefer to use Zephyr's native STM32WL LoRa driver instead:
- Enable `CONFIG_STM32WL_SUBGHZ=y` and `CONFIG_LORA=y` in your configuration
- Use Zephyr's `lora_configure()`, `lora_transmit()`, `lora_receive()` APIs
- This project defaults to STM32CubeWL for continuity with your existing code

---

## Node configuration

Each Nucleo must have a unique node ID. Build two separate binaries:

**Node A (drone/FC side):**
```kconfig
CONFIG_THIS_NODE_ID=1   # 0x01 — this node sends to Node B
CONFIG_TARGET_NODE_ID=2  # 0x02 — who we send to
```

**Node B (ground station):**
```kconfig
CONFIG_THIS_NODE_ID=2   # 0x02 — this node sends to Node A (ACKs)
CONFIG_TARGET_NODE_ID=1  # 0x01 — who we send to
```

Set via `project.conf`:
```ini
CONFIG_THIS_NODE_ID=1
CONFIG_TARGET_NODE_ID=2
```

Or via `menuconfig`:
```bash
west build -t menuconfig
```

---

## Validation with Python logger

Your existing logger methodology works unchanged:

```bash
# Terminal A: TX Nucleo (drone) → COM8
python mavlink_both_ends_logger.py tx --port COM8 --baud 115200 --bps 13120

# Terminal B: RX Nucleo (ground) → COM7 (must forward MAVLink to UART)
python mavlink_both_ends_logger.py rx --port COM7 --baud 115200

# After capture:
python mavlink_both_ends_logger.py compare \
    --tx-log logs/tx_XXXX.jsonl --rx-log logs/rx_XXXX.jsonl
```

**Expected result with ARQ + zero loss:**
```
TX frames: 5000  from logs\tx_XXXX.jsonl
RX frames: 5000  from logs\rx_XXXX.jsonl
RX sha matched to some TX: 5000 (events)
Unique TX frames seen on RX: 5000 / 5000
Delivery ratio (unique): 100.0%
Missing TX frames: 0
```

The ARQ protocol ensures every MAVLink frame sent by the TX logger is eventually received by the RX logger. The RX log will show a complete, ordered MAVLink stream with no gaps (because ARQ retransmits any lost frames).

**Important:** The RX Nucleo firmware must forward the received MAVLink payloads to UART2 TX. In our code, `uart_forward_thread_fn()` does this — it takes frames from the ARQ RX queue and sends them via `HAL_UART_Transmit_DMA(&huart2, ...)`. This is the same pattern as your FSK code's `RfToUart_Process()`.

---

## Troubleshooting

### Build fails — board not found
Check `west boards | grep wl`. If `nucleo_wl55jc1` is not listed:
- Use a generic STM32WL board DTS and override with `.overlay`
- Add the Nucleo board definition to your Zephyr workspace

### LoRa TX doesn't work
- Verify STM32CubeWL LoRa init sequence is correct
- Check `Radio.SetRxConfig(MODEM_LORA, ...)` is called before `Radio.Rx()`
- Verify `CONFIG_LORA_SF=5`, `CONFIG_LORA_BW=125000`, `CONFIG_LORA_CR=2`
- Use a LoRa receiver (e.g., another Nucleo in RX-only mode, or a LoRa dongle/level) to verify TX packets are on air

### UART2 DMA not working
- Same issues as your FSK code — check UART2 init, DMA stream mapping, IDLE interrupt
- The `uart_dma.c` in this project is based on your validated FSK code, so it should work if the HAL init is correct

### Delivery ratio < 100% in compare
- This means raw packet loss is occurring and ARQ is retransmitting
- Check `diagnostics.c` output: look at `arq_retransmissions`, `mac_frames_tx`, `mac_frames_rx`
- If retransmissions are high (>20%), the link is marginal — see link budget analysis
- Use a spectrum analyzer or LoRa receiver to verify packets are on air
- Check antenna connections, orientation, placement (avoid metal, keep antenna clear)
- Try different locations/orientations to find a better RF path

### Python logger shows "invalid" frames or parse errors
- The RX Nucleo must forward **raw MAVLink2 frames** (0xFD STX format) to UART2 TX
- If the firmware is corrupting the MAVLink frames (e.g., partial sends, buffer issues), the logger's MAVLink reassembler will fail
- Verify the `uart_forward_thread_fn()` is correctly forwarding the payload (not the MAC header)
- The MAC header (8 bytes) is stripped before forwarding — only the MAVLink payload goes to UART

---

## Limitations & when this won't work

### This approach will NOT achieve zero loss when:

1. **Heavy urban NLOS at 7 km**: Buildings, dense foliage, and multipath at 866 MHz with 13 kbps chirp and 0 dBi antennas will likely cause raw FER > 50%, leading to excessive ARQ retransmissions and effectively unusable throughput.

2. **Very deep fades (shadowing > 25 dB)**: If the link experiences transient deep fades (e.g., drone flies behind a building, tree sways into the path), the instantaneous SNR may drop below the LoRa demodulation threshold for seconds at a time. ARQ can handle this if the fade is short (< ARQ_ACK_TIMEOUT), but long fades will cause batch timeouts and retransmissions that may not complete.

3. **Interference from other LoRa/Wi-Fi/sub-GHz users**: If there's significant interference on the 866 MHz band, the LoRa modem's CRC will reject packets, increasing ARQ load. In India's 866 MHz ISM band, this is generally not a problem (it's a quiet band compared to 2.4 GHz), but industrial environments with sub-GHz sensors may have interference.

4. **Regulatory TX power limits**: India's 866 MHz ISM band has TX power limits. The STM32WL55's +22 dBm may exceed the allowed EIRP in some contexts. Check your local regulations. If you're limited to lower TX power (e.g., +14 or +17 dBm), the range will decrease proportionally.

5. **Throughput requirements above ~30-40 pkt/s**: With ARQ batch size 8 and RTT ~280 ms, the maximum effective throughput is ~28 pkt/s (8 frames / 0.28 s). If you need 47 pkt/s (your current FSK rate), ARQ at this batch size won't achieve it. You'd need:
   - Larger batch size (but this increases retransmission waste)
   - Shorter RTT (faster ACK, but limited by airtime)
   - Lower raw FER (better link margin)
   - Or a different approach (no ARQ, accept some loss)

### The physical reality of 13 kbps NLOS at 5-7 km

The fundamental challenge is that **13 kbps at 866 MHz with 0 dBi antennas and +22 dBm is near the practical limit for uncoded NLOS**. LoRa SF5 gives you 12-15 dB of margin over FSK, which is significant, but it's not magic — it doesn't change the path loss or overcome deep fades.

For guaranteed zero loss at 7 km NLOS, you'd typically want:
- **10-20 dB more link margin** than the minimum demodulation threshold
- **Lower data rate** (higher SF) for more sensitivity (but you want 13 kbps)
- **Higher antenna gain** (directional antenna on at least one end)
- **External PA** for more TX power

Without these, the LoRa SF5 + ARQ approach is the best software-only solution, but it has limits.

---

## File manifest

```
zephyr_lora_reliable_bridge/
├── README.md                          # This file
├── README_LINK_BUDGET.md             # Link budget analysis (see separate file)
├── project.conf                      # Zephyr app config
├── CMakeLists.txt                    # Build file (STM32CubeWL sources)
├── Kconfig                           # Tunable parameters
├── lora_reliable_bridge.overlay      # Device tree overlay (UART2, DMA, LoRa GPIOs)
├── include/
│   ├── lora_reliable_bridge.h        # Public API + configuration macros
│   └── lora_phy.h                    # LoRa PHY abstraction (wrapper interface)
└── src/
    ├── main.c                        # Zephyr entry point + HAL init + thread creation
    ├── lora_phy.c                    # LoRa PHY wrapper (STM32CubeWL LoRa API calls)
    ├── mac_layer.c                   # MAC frame builder/parser (header, seq, type, CRC)
    ├── arq_manager.c                 # ARQ state machine (window, ACK, NACK, retry, timeout)
    ├── bridge_app.c                  # Top-level bridge (UART↔MAVLink↔ARQ↔LoRa orchestration)
    ├── uart_dma.c                    # UART2 DMA circular buffer + IDLE detection (from your FSK code)
    └── diagnostics.c                 # Counters, RSSI/SNR logging, debugging output
```

**Key difference from your FSK code:** The PHY layer (`lora_phy.c`) uses `MODEM_LORA` instead of `MODEM_FSK`, and the MAC/ARQ layers (`mac_layer.c`, `arq_manager.c`) are added to provide the reliability that FSK lacked. The UART DMA bridge (`uart_dma.c`) and ring buffer architecture are preserved from your FSK code.

---

*Zephyr RTOS port of the validated STM32CubeWL Sub-GHz link for Nucleo-WL55JC1. Uses the chip's native LoRa transceiver (SF5, 125 kHz, CR 4/6 → 13.02 kbps) with ARQ for zero-loss delivery. Software-only — no hardware changes required.*
