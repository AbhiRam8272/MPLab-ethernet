/**
 * lora_phy.c — LoRa PHY wrapper (STM32CubeWL LoRa API)
 * ======================================================
 * Wraps STM32CubeWL's Radio_* API for LoRa mode.
 * Replaces your current FSK Radio_* calls with LoRa equivalents.
 *
 * LoRa configuration: SF5, 125 kHz BW, CR 4/6 → 13,020 bps
 * This is the closest LoRa mode to your 13.12 kbps FSK target.
 *
 * The STM32WL55 LoRa transceiver gives ~12-14 dB better sensitivity than
 * FSK at this data rate (LoRa processing gain + below-noise reception).
 * This is the PHY-layer foundation for 5-7 km NLOS feasibility.
 *
 * Callbacks (TxDone, RxDone, TxTimeout, RxTimeout, RxError) fire from
 * the STM32CubeWL LoRa modem's ISR context and signal the bridge thread
 * via semaphore.
 */

#include <zephyr.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>
#include <errno.h>

#include "lora_phy.h"
#include "lora_reliable_bridge.h"

/*
 * STM32CubeWL HAL headers — from your STM32CubeWL package.
 * In a Zephyr project, these come from the package's inc/ directories.
 */
#include "stm32wlxx_hal.h"   /* STM32WL HAL — RCC, GPIO, IRQ */
#include "radio.h"           /* ST RF HAL — Radio type, RadioEvents_t, Radio_* API */

/*
 * Note: STM32CubeWL's Radio API for LoRa uses the SAME function names as FSK:
 *   Radio.Init(&RadioEvents)
 *   Radio.SetRxConfig(MODEM_LORA, ...)    // instead of MODEM_FSK
 *   Radio.SetTxConfig(MODEM_LORA, ...)    // instead of MODEM_FSK
 *   Radio.Send(payload, len)
 *   Radio.Rx(timeout)                      // starts RX; callback fires on packet
 *   Radio.Sleep()
 *
 * The difference: MODEM_LORA + LoRa-specific config parameters.
 * See STM32CubeWL's radio.h for exact parameter mapping.
 */

/* ============================================================================
 * LoRa configuration constants (from Kconfig/project.conf)
 * ============================================================================ */

/* Spreading Factor: 5 → ~13,020 bps at 125 kHz BW, CR 4/6 */
#ifndef CONFIG_LORA_SF
#define CONFIG_LORA_SF  5
#endif

/* Bandwidth: 125 kHz (standard LoRa BW for SF5-SF12) */
#define LORA_BW_125KHZ  0   /* STM32CubeWL bandwidth index for 125 kHz (adjust per version) */

/* Coding Rate: 4/6 (CR index 2 in STM32CubeWL: 4/5=1, 4/6=2, 4/7=3, 4/8=4) */
#ifndef CONFIG_LORA_CR
#define CONFIG_LORA_CR  2   /* 4/6 → gives ~13.02 kbps with SF5, 125 kHz */
#endif

/* Frequency: 866 MHz (India ISM band) */
#ifndef CONFIG_LORA_FREQUENCY_HZ
#define CONFIG_LORA_FREQUENCY_HZ  866000000U
#endif

/* TX power: +22 dBm (STM32WL55 internal PA max) */
#ifndef CONFIG_LORA_TX_POWER_DBM
#define CONFIG_LORA_TX_POWER_DBM  22
#endif

/* LoRa preamble: 8 symbols (standard LoRa preamble for P2P) */
#define LORA_PREAMBLE_SYMBOLS  8U

/* LoRa CRC: enabled (modem adds CRC to each packet) */
#define LORA_CRC_ENABLED  1U

/* LoRa sync word: 0x00 (private network, not LoRaWAN public) */
#define LORA_SYNC_WORD  0x00U

/* ============================================================================
 * LoRa PHY state
 * ============================================================================ */
static Radio_t  Radio;              /* STM32CubeWL Radio handle — from HAL init */
static RadioEvents_t  RadioEvents;  /* LoRa event callbacks */

static uint32_t phy_frequency_hz    = CONFIG_LORA_FREQUENCY_HZ;
static uint8_t  phy_spreading_factor = CONFIG_LORA_SF;
static uint8_t  phy_bandwidth_index  = LORA_BW_125KHZ;
static uint8_t  phy_coding_rate      = CONFIG_LORA_CR;
static uint8_t  phy_tx_power_dbm     = CONFIG_LORA_TX_POWER_DBM;

/* RX buffer and state */
static uint8_t  phy_rx_buffer[256];   /* max LoRa packet (SF5: up to ~256 bytes) */
static volatile uint16_t phy_rx_len   = 0;
static volatile bool      phy_rx_active = false;

/* Last received signal quality (for diagnostics) */
static volatile int16_t  phy_last_rssi = 0;
static volatile int8_t   phy_last_snr  = 0;

/* Semaphore: LoRa events (TX done, RX done, timeout, error) → bridge thread */
static struct k_sem sem_lora_event;

/* ============================================================================
 * LoRa PHY initialization
 * ============================================================================ */
int lora_phy_init(void) {
    /*
     * Initialize the STM32CubeWL LoRa Radio peripheral.
     *
     * In your STM32CubeWL project, the init sequence is:
     *   HAL_Init()
     *   SystemClock_Config()  → HSI, PLL → 48 MHz core, 32 MHz RF
     *   MX_GPIO_Init()        → RF switch GPIO, LEDs, etc.
     *   MX_RADIO_Init()       → LoRa/FSK radio peripheral init
     *   Radio.Init(&RadioEvents)  → register callbacks
     *
     * For Zephyr, you need to include the STM32CubeWL init sequence.
     * The simplest path: call the STM32CubeWL init from main() before
     * lora_phy_init(). See main.c for the hal_system_init_stm32cw() stub.
     *
     * This function registers the LoRa callbacks and assumes the HAL
     * is already initialized.
     */
    RadioEvents.TxDone      = lora_phy_on_txdone;
    RadioEvents.RxDone      = lora_phy_on_rxdone;
    RadioEvents.TxTimeout   = lora_phy_on_txtimeout;
    RadioEvents.RxTimeout   = lora_phy_on_rxtimeout;
    RadioEvents.RxError     = lora_phy_on_rxerror;

    /* Radio.Init() — initializes the STM32WL RF peripheral */
    Radio.Init(&RadioEvents);

    /* Initialize semaphore */
    k_sem_init(&sem_lora_event, 0, 1);

    printk("[LoRa PHY] Init: SF%d, BW 125kHz, CR 4/%d, %u Hz, TX %d dBm\n",
           phy_spreading_factor, phy_coding_rate + 5,  /* CR 4/6 → display 4/6 */
           phy_frequency_hz, phy_tx_power_dbm);

    return 0;
}

/* ============================================================================
 * Configure LoRa parameters (call once before TX/RX)
 * ============================================================================ */
int lora_phy_configure(void) {
    /*
     * Configure LoRa TX parameters.
     * Radio.SetTxConfig(MODEM_LORA, tx_power, freq_offset, frequency,
     *                    bandwidth_idx, datarate, preamble_len, preamble_on,
     *                    crc_on, payload_len, tx_timeout, symb_timeout,
     *                    tx_gain_auto, 0)
     *
     * For LoRa, the parameter order differs from FSK. Adjust to your
     * STM32CubeWL version's radio.h. The key LoRa TX parameters:
     *   modem    = MODEM_LORA
     *   power    = TX output power (dBm)
     *   freq     = carrier frequency
     *   preamble = number of preamble symbols
     *   crc      = 1 (LoRa CRC enabled)
     */
    Radio.SetTxConfig(MODEM_LORA,
                      phy_tx_power_dbm,   /* TX power (dBm) */
                      0,                  /* frequency offset */
                      phy_frequency_hz,   /* carrier frequency */
                      0,                  /* bandwidth (not used for LoRa TX config in some versions) */
                      phy_spreading_factor, /* spreading factor */
                      LORA_PREAMBLE_SYMBOLS, /* preamble length */
                      LORA_PREAMBLE_SYMBOLS, /* preamble on */
                      LORA_CRC_ENABLED,   /* CRC on */
                      0,                  /* payload length (0 = variable) */
                      0,                  /* TX timeout (symbols, LoRa typically 0) */
                      0,                  /* symbol timeout */
                      0,                  /* TX gain auto (0 = auto) */
                      0);

    /*
     * Configure LoRa RX parameters.
     * Radio.SetRxConfig(MODEM_LORA, bandwidth_idx, datarate, freq_offset,
     *                    afc_bw, preamble_len, symb_timeout, crc_on,
     *                    rx_single_mode, sync_word, 0, 0, 0, tx_continuous, 1)
     *
     * For LoRa:
     *   modem           = MODEM_LORA
     *   bandwidth_idx   = 125 kHz bandwidth index
     *   datarate        = spreading factor (SF5 = 5)
     *   preamble_len    = preamble symbols
     *   crc_on          = 1
     *   rx_single_mode  = 0 (continuous RX) — we listen for multiple packets
     *   sync_word       = 0x00 (private network, not LoRaWAN public 0x12)
     *   last param     = 1 (RX on)
     */
    Radio.SetRxConfig(MODEM_LORA,
                      phy_bandwidth_index,   /* 125 kHz BW */
                      phy_spreading_factor,  /* SF5 */
                      0,                     /* frequency offset */
                      0,                     /* AFC bandwidth (not used for LoRa) */
                      LORA_PREAMBLE_SYMBOLS, /* preamble */
                      0,                     /* symbol timeout (0 = default) */
                      LORA_CRC_ENABLED,      /* CRC on */
                      0,                     /* RX single mode (0 = continuous) */
                      LORA_SYNC_WORD,        /* sync word (private P2P) */
                      0, 0, 0,
                      0,                     /* TX continuous (not used) */
                      1);                    /* RX on */

    return 0;
}

/* ============================================================================
 * LoRa TX — send a packet
 * ============================================================================ */
int lora_phy_tx(const uint8_t *payload, uint16_t len) {
    if (len > sizeof(phy_rx_buffer)) {
        return -EINVAL;
    }

    /*
     * Radio.Send() sends the LoRa packet and returns immediately.
     * The TxDone callback fires when TX is complete (~15 ms for our packet size).
     * This is how we implement half-duplex: TX, wait for TxDone, then switch to RX.
     */
    Radio.Send((uint8_t *)payload, len);
    return 0;
}

/* ============================================================================
 * LoRa RX — start listening (continuous RX mode)
 * ============================================================================ */
int lora_phy_rx_start(void) {
    /*
     * Radio.Rx(0) starts continuous RX mode.
     * The RxDone callback fires for each received packet (that passes LoRa CRC).
     * We use continuous RX to listen for an entire batch of packets from the TX node.
     */
    Radio.Rx(0);  /* 0 = continuous RX (or no timeout) */
    phy_rx_active = true;
    phy_rx_len    = 0;
    return 0;
}

/* ============================================================================
 * LoRa RX — check for received packet (non-blocking)
 * ============================================================================ */
int lora_phy_rx_check(uint8_t *payload, uint16_t *len) {
    if (!phy_rx_active) {
        return -EBUSY;
    }
    if (phy_rx_len == 0) {
        return -EAGAIN;  /* no packet available */
    }

    /* Copy payload to caller's buffer */
    if (payload && len) {
        if (*len < phy_rx_len) {
            return -EINVAL;  /* caller buffer too small */
        }
        memcpy(payload, phy_rx_buffer, phy_rx_len);
        *len = phy_rx_len;
    }

    /* Clear RX buffer (packet consumed) */
    phy_rx_len = 0;
    return 0;
}

/* ============================================================================
 * LoRa RX — get last signal quality (RSSI, SNR)
 * ============================================================================ */
int16_t lora_phy_get_last_rssi(void) {
    return phy_last_rssi;
}

int8_t lora_phy_get_last_snr(void) {
    return phy_last_snr;
}

/* ============================================================================
 * LoRa callbacks — called from STM32CubeWL LoRa modem ISR
 * ============================================================================ */

void lora_phy_on_txdone(void) {
    /*
     * TX complete. Used for half-duplex coordination:
     * - After TX'ing a batch, the TX node waits for TxDone, then switches
     *   to RX mode to listen for the ACK from the RX node.
     */
    k_sem_give(&sem_lora_event);
}

void lora_phy_on_rxdone(uint8_t *payload, uint16_t size,
                        int16_t rssi, int8_t snr) {
    /*
     * RX packet received (passed LoRa CRC).
     *
     * Store payload + signal quality for the bridge thread to consume.
     * The bridge thread checks this buffer and processes the MAC frame.
     */
    if (size > sizeof(phy_rx_buffer)) {
        /* Packet too large — discard (shouldn't happen with our MAC frame sizes) */
        phy_rx_len = 0;
        return;
    }

    memcpy(phy_rx_buffer, payload, size);
    phy_rx_len   = size;
    phy_last_rssi = rssi;
    phy_last_snr  = snr;

    /* Signal bridge thread that a packet is ready */
    k_sem_give(&sem_lora_event);
}

void lora_phy_on_txtimeout(void) {
    /* TX timeout — shouldn't happen with our packet sizes and SF5 */
    k_sem_give(&sem_lora_event);
}

void lora_phy_on_rxtimeout(void) {
    /*
     * RX timeout — in continuous RX mode, this fires if no packet is received
     * within the timeout period. We use this as a "batch end" indicator:
     * after a gap in RX (timeout), the batch is complete and the RX node
     * should send the ACK.
     */
    phy_rx_len = 0;  /* clear partial packet */
    k_sem_give(&sem_lora_event);
}

void lora_phy_on_rxerror(void) {
    /*
     * RX error — packet failed CRC or other error.
     * The LoRa modem typically doesn't deliver packets that fail CRC,
     * so this callback is for edge cases (e.g., corrupted payload that
     * somehow passed CRC, or receiver budget issues).
     */
    phy_rx_len = 0;
    k_sem_give(&sem_lora_event);
}
