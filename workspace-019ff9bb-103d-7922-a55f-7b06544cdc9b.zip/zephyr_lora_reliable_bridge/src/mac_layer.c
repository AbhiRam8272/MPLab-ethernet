/**
 * mac_layer.c — MAC frame builder/parser for the LoRa reliable bridge
 * ====================================================================
 * Implements the MAC-layer framing for the ARQ protocol.
 *
 * MAC frame format (what goes over LoRa, after the LoRa modem adds preamble+CRC):
 *
 *   [MAC Header: 8 bytes]
 *     [0] Frame type:   0=Data, 1=ACK, 2=NACK, 3=EndOfBatch
 *     [1] TX node ID:   this node's ID (0x01 or 0x02)
 *     [2] RX node ID:   target node's ID
 *     [3] Reserved:     0x00
 *     [4] Group seq LSB: 16-bit group sequence number (increments per batch)
 *     [5] Group seq MSB:
 *     [6] Frame seq LSB: 16-bit frame sequence within group
 *     [7] Frame seq MSB:
 *
 *   [MAC Payload: variable, 21-43 bytes = MAVLink frame]
 *     The MAVLink2 frame (0xFD STX format) from the flight controller.
 *     This is the same format the Python logger expects.
 *
 *   Total on LoRa: 8 + (21-43) = 29-51 bytes  (airtime ~13-20 ms at SF5 125kHz)
 *
 * The MAC layer is responsible for:
 *   - Building the MAC header for TX frames
 *   - Parsing the MAC header for RX frames
 *   - Detecting frame type (Data vs ACK vs NACK)
 *   - Validating sequence numbers (gap detection for ARQ)
 *   - CRC check (the LoRa modem handles physical CRC; MAC adds optional integrity check)
 *
 * Sequence numbering:
 *   - group_sequence: increments each batch (batch = N frames + ACK opportunity)
 *   - frame_sequence: increments each frame within a batch (0..N-1)
 *   - This allows the RX to detect missing frames within a batch and request
 *     retransmission via NACK, or the TX to know which frames to retransmit.
 *
 * For the ARQ protocol:
 *   - TX sends batch of N frames (each with frame_seq 0..N-1)
 *   - RX receives batch, detects gaps, sends ACK/NACK
 *   - ACK: cumulative — "I received up to frame_seq X"
 *   - NACK: selective — "I missed frames with seq Y, Z" (optional, for efficiency)
 *   - TX retransmits unacknowledged frames in next batch
 *
 * The MAC layer does NOT implement ARQ itself — it just builds/parses frames
 * and provides the sequence/CRC functionality that the ARQ manager uses.
 */

#include <zephyr.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>
#include <errno.h>

#include "lora_reliable_bridge.h"

/* ============================================================================
 * MAC frame format constants
 * ============================================================================ */
#define MAC_HEADER_SIZE   8U   /* fixed 8-byte header */
#define MAC_PAYLOAD_MIN   21U  /* minimum MAVLink frame (HEARTBEAT) */
#define MAC_PAYLOAD_MAX   43U  /* maximum MAVLink frame (SYS_STATUS) we send */
#define MAC_FRAME_MIN     (MAC_HEADER_SIZE + MAC_PAYLOAD_MIN)  /* 29 bytes */
#define MAC_FRAME_MAX     (MAC_HEADER_SIZE + MAC_PAYLOAD_MAX)  /* 51 bytes */

/* Frame types */
#define MAC_FRAME_TYPE_DATA    0U
#define MAC_FRAME_TYPE_ACK     1U
#define MAC_FRAME_TYPE_NACK    2U
#define MAC_FRAME_TYPE_END     3U   /* end-of-batch marker (optional) */

/* ============================================================================
 * MAC frame structure (for building/parsing)
 * ============================================================================ */
typedef struct {
    uint8_t  frame_type;       /* 0=Data, 1=ACK, 2=NACK, 3=EndOfBatch */
    uint8_t  tx_node_id;       /* TX node ID (who sent this) */
    uint8_t  rx_node_id;       /* RX node ID (who this is for) */
    uint8_t  reserved;         /* 0x00 */
    uint16_t group_sequence;   /* 16-bit group sequence (per batch) */
    uint16_t frame_sequence;   /* 16-bit frame sequence (per frame within batch) */
    uint8_t  payload_len;      /* MAVLink payload length (21-43 bytes) */
    uint8_t  payload[43];      /* MAVLink frame payload (variable) */
} mac_frame_t;

/* ============================================================================
 * Build a MAC data frame (TX side)
 * ============================================================================ */
int mac_build_data_frame(uint8_t *buffer, uint16_t buffer_size,
                         uint16_t group_seq, uint16_t frame_seq,
                         const uint8_t *mavlink_payload, uint8_t mavlink_len,
                         uint8_t tx_node_id, uint8_t rx_node_id) {
    if (buffer_size < (MAC_HEADER_SIZE + mavlink_len)) {
        return -EINVAL;
    }
    if (mavlink_len < MAC_PAYLOAD_MIN || mavlink_len > MAC_PAYLOAD_MAX) {
        return -EINVAL;
    }

    /* MAC header */
    buffer[0] = MAC_FRAME_TYPE_DATA;
    buffer[1] = tx_node_id;
    buffer[2] = rx_node_id;
    buffer[3] = 0x00;  /* reserved */
    buffer[4] = (uint8_t)(group_seq & 0xFFU);
    buffer[5] = (uint8_t)(group_seq >> 8U);
    buffer[6] = (uint8_t)(frame_seq & 0xFFU);
    buffer[7] = (uint8_t)(frame_seq >> 8U);

    /* MAVLink payload */
    memcpy(&buffer[MAC_HEADER_SIZE], mavlink_payload, mavlink_len);

    return (int)(MAC_HEADER_SIZE + mavlink_len);  /* total frame length */
}

/* ============================================================================
 * Parse a received MAC frame (RX side)
 * ============================================================================ */
int mac_parse_frame(const uint8_t *buffer, uint16_t size,
                    mac_frame_t *frame) {
    if (size < MAC_HEADER_SIZE) {
        return -EINVAL;
    }

    /* Parse header */
    frame->frame_type   = buffer[0];
    frame->tx_node_id   = buffer[1];
    frame->rx_node_id   = buffer[2];
    frame->reserved     = buffer[3];
    frame->group_sequence = (uint16_t)buffer[4] | ((uint16_t)buffer[5] << 8U);
    frame->frame_sequence = (uint16_t)buffer[6] | ((uint16_t)buffer[7] << 8U);

    /* Validate frame type */
    if (frame->frame_type > MAC_FRAME_TYPE_END) {
        return -EINVAL;
    }

    /* For data frames, parse the MAVLink payload */
    if (frame->frame_type == MAC_FRAME_TYPE_DATA) {
        uint16_t payload_len = size - MAC_HEADER_SIZE;
        if (payload_len < MAC_PAYLOAD_MIN || payload_len > MAC_PAYLOAD_MAX) {
            return -EINVAL;
        }
        frame->payload_len = (uint8_t)payload_len;
        if (frame->payload_len > sizeof(frame->payload)) {
            return -EINVAL;
        }
        memcpy(frame->payload, &buffer[MAC_HEADER_SIZE], frame->payload_len);
    } else {
        /* ACK, NACK, EndOfBatch — no payload */
        frame->payload_len = 0;
    }

    return 0;
}

/* ============================================================================
 * Build an ACK frame (RX side → TX side)
 * ============================================================================ */
int mac_build_ack_frame(uint8_t *buffer, uint16_t buffer_size,
                        uint16_t group_seq, uint16_t last_received_frame_seq,
                        uint8_t tx_node_id, uint8_t rx_node_id) {
    /*
     * ACK frame: acknowledges receipt of all frames up to last_received_frame_seq
     * in the given group.
     *
     * The TX node uses this to know which frames to retransmit.
     */
    if (buffer_size < MAC_HEADER_SIZE) {
        return -EINVAL;
    }

    buffer[0] = MAC_FRAME_TYPE_ACK;
    buffer[1] = tx_node_id;   /* TX side's node ID (who this ACK is FROM) */
    buffer[2] = rx_node_id;   /* RX side's node ID (who this ACK is TO) */
    buffer[3] = 0x00;
    buffer[4] = (uint8_t)(group_seq & 0xFFU);
    buffer[5] = (uint8_t)(group_seq >> 8U);
    buffer[6] = (uint8_t)(last_received_frame_seq & 0xFFU);
    buffer[7] = (uint8_t)(last_received_frame_seq >> 8U);

    return (int)MAC_HEADER_SIZE;  /* ACK has no payload */
}

/* ============================================================================
 * Build a NACK frame (RX side → TX side) — optional, for selective retransmission
 * ============================================================================ */
int mac_build_nack_frame(uint8_t *buffer, uint16_t buffer_size,
                         uint16_t group_seq,
                         const uint16_t *missing_frame_seqs, uint8_t missing_count,
                         uint8_t tx_node_id, uint8_t rx_node_id) {
    /*
     * NACK frame: selectively lists missing frame sequence numbers.
     * This allows the TX to retransmit only the missing frames, not the whole batch.
     *
     * Limited to 2 missing frames in the payload (8 bytes header + 2*2 bytes seq + 2 bytes count = 14 bytes).
     * For larger missing counts, fall back to ACK with last_received (cumulative).
     */
    if (buffer_size < MAC_HEADER_SIZE + 2U) {
        return -EINVAL;
    }
    if (missing_count > 2) {
        /* Too many missing frames for NACK payload — use ACK instead */
        return -EINVAL;
    }

    buffer[0] = MAC_FRAME_TYPE_NACK;
    buffer[1] = tx_node_id;
    buffer[2] = rx_node_id;
    buffer[3] = 0x00;
    buffer[4] = (uint8_t)(group_seq & 0xFFU);
    buffer[5] = (uint8_t)(group_seq >> 8U);
    buffer[6] = (uint8_t)(missing_count & 0xFFU);   /* number of missing frames */
    buffer[7] = (uint8_t)((missing_count >> 8U) & 0xFFU);

    /* Missing frame sequence numbers (up to 2) */
    if (missing_count >= 1) {
        buffer[MAC_HEADER_SIZE + 0] = (uint8_t)(missing_frame_seqs[0] & 0xFFU);
        buffer[MAC_HEADER_SIZE + 1] = (uint8_t)(missing_frame_seqs[0] >> 8U);
    }
    if (missing_count >= 2) {
        buffer[MAC_HEADER_SIZE + 2] = (uint8_t)(missing_frame_seqs[1] & 0xFFU);
        buffer[MAC_HEADER_SIZE + 3] = (uint8_t)(missing_frame_seqs[1] >> 8U);
    }

    return (int)(MAC_HEADER_SIZE + 2U * missing_count);
}

/* ============================================================================
 * MAC statistics
 * ============================================================================ */
static mac_diag_t mac_diag = {0};

const mac_diag_t *mac_get_diag(void) {
    return &mac_diag;
}

void mac_reset_diag(void) {
    memset(&mac_diag, 0, sizeof(mac_diag));
}
