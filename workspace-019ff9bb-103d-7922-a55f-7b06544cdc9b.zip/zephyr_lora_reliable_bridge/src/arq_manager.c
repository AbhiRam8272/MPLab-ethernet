/**
 * arq_manager.c — ARQ (Automatic Repeat reQuest) state machine
 * ================================================================
 * Implements the selective-repeat ARQ protocol for zero-loss LoRa delivery.
 *
 * ARQ PROTOCOL (half-duplex, batch-based):
 *
 * TX Node (drone/airborne):
 *   1. Collect MAVLink frames into an ARQ send window (size = ARQ_BATCH_SIZE)
 *   2. Assign each frame a sequence number (16-bit, monotonic across all batches)
 *   3. Build LoRa packets (MAC header + MAVLink payload) and TX them one by one
 *   4. After the batch is TX'd, switch to RX mode and listen for ACK from RX
 *   5. ACK contains: last cumulative received frame sequence number
 *   6. Frames with seq > ACK are unacknowledged → retransmit in next batch
 *   7. If no ACK within ARQ_ACK_TIMEOUT: retransmit unacknowledged frames
 *
 * RX Node (ground station):
 *   1. Continuous RX mode: listen for TX batch
 *   2. For each packet received:
 *      - Validate MAC header (node IDs match)
 *      - Validate LoRa CRC (done by modem)
 *      - Extract frame sequence number
 *      - If seq is new (not a duplicate): deliver MAVLink payload to UART
 *      - Track expected next frame sequence (detect gaps)
 *   3. After batch complete (RX timeout or max batch size reached):
 *      - Build ACK: cumulative last received frame seq
 *      - TX ACK packet over LoRa
 *   4. Switch back to RX mode for next batch
 *
 * HALF-DUPLEX COORDINATION:
 *   - TX and RX cannot operate simultaneously on the STM32WL LoRa modem.
 *   - TX Node: TX batch → TxDone callback → switch to RX → wait for ACK
 *   - RX Node: RX batch → detect batch end → switch to TX → send ACK → switch to RX
 *   - The loraphy_event_thread manages the TX/RX mode switching based on
 *     LoRa callbacks.
 *
 * ARQ STATE (per bridge instance):
 *   tx_state:
 *     - IDLE: no batch in progress, waiting for MAVLink frames to arrive
 *     - BUILDING: collecting frames into current batch
 *     - TXING: TX'ing batch packets one by one
 *     - WAITING_ACK: batch TX'd, listening for ACK from RX
 *   rx_state:
 *     - LISTENING: continuous RX, receiving batch packets
 *     - SENDING_ACK: TX'ing ACK packet to TX node
 *
 * SEQUENCE NUMBERS:
 *   - arq_tx_seq: 16-bit, increments for each MAVLink frame TX'd (across all batches)
 *     This is the "frame sequence" in the MAC header.
 *   - arq_rx_expected_seq: 16-bit, the next frame sequence the RX expects
 *     Used to detect gaps (missing frames) in the RX stream.
 *   - arq_last_ack_seq: the last sequence number that was ACK'd by the RX
 *     (TX side uses this to know which frames are acknowledged).
 *
 * WINDOW / BATCH:
 *   - arq_batch_size: number of frames per batch (default 8)
 *   - arq_tx_window: linked list of frames waiting to be acked
 *     Each frame: { seq, mavlink_payload, mavlink_len, acked }
 *   - arq_tx_batch_seq: 16-bit group sequence, increments per batch
 *
 * RETRANSMISSION:
 *   - Unacknowledged frames are kept in the window with their original seq.
 *   - When the batch is rebuilt for retransmission, the same seq numbers are used
 *     (so the RX can recognize them as retransmissions and not deliver duplicates).
 *   - The RX dedup logic: if a frame with seq ≤ last_delivered_seq arrives, it's
 *     a duplicate → skip (don't deliver to UART, don't count as new).
 *
 * TIMEOUTS:
 *   - ARQ_ACK_TIMEOUT (default 300 ms): if no ACK received within this time
 *     after batch TX complete, retransmit unacknowledged frames.
 *   - This is implemented via the Zephyr arq_retry_timer (100 ms period).
 *
 * THROUGHPUT / LATENCY TRADEOFF:
 *   - Larger batch (16 frames): fewer turnarounds, higher throughput, more
 *     retransmission overhead when packet loss occurs.
 *   - Smaller batch (4 frames): more turnarounds, lower throughput, less waste.
 *   - Default 8: balances throughput (~30-40 pkt/s effective) with efficiency.
 *     At 13.02 kbps air rate, airtime-limited max is ~50 pkt/s.
 *     With batch 8 and RTT 280 ms: 8 pkt / ~280 ms ≈ 28.6 pkt/s effective.
 *     This is lower than your current 47 pkt/s, but it's the cost of zero loss.
 *   - If you need higher throughput, increase batch size (but RTT increases).
 *
 * MAVLINK SEQUENCE vs ARQ SEQUENCE:
 *   - MAVLink frames have their own sequence number (the `seq` field in the
 *     MAVLink2 header, 0-255, wraps).
 *   - ARQ uses a separate 16-bit sequence number for its own frame tracking.
 *   - Both sequences are forwarded to the RX side. The Python logger sees the
 *     MAVLink seq. The ARQ seq is internal to the bridge.
 */

#include <zephyr.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>
#include <errno.h>

#include "lora_reliable_bridge.h"
#include "lora_phy.h"
#include "mac_layer.h"
#include "arq_manager.h"
#include "uart_dma.h"
#include "diagnostics.h"

/* ============================================================================
 * ARQ configuration (from Kconfig/project.conf — must match on both nodes)
 * ============================================================================ */
#ifndef CONFIG_THIS_NODE_ID
#define CONFIG_THIS_NODE_ID  1
#endif
#ifndef CONFIG_TARGET_NODE_ID
#define CONFIG_TARGET_NODE_ID  2
#endif

#ifndef CONFIG_ARQ_BATCH_SIZE
#define CONFIG_ARQ_BATCH_SIZE  8
#endif
#ifndef CONFIG_ARQ_ACK_TIMEOUT_MS
#define CONFIG_ARQ_ACK_TIMEOUT_MS  300
#endif
#ifndef CONFIG_ARQ_MAX_RETRIES
#define CONFIG_ARQ_MAX_RETRIES  5
#endif

/* ============================================================================
 * ARQ state
 * ============================================================================ */
typedef enum {
    ARQ_TX_IDLE,
    ARQ_TX_BUILDING,
    ARQ_TX_TXING,
    ARQ_TX_WAITING_ACK,
    ARQ_RX_LISTENING,
    ARQ_RX_SENDING_ACK,
} arq_state_t;

typedef struct {
    uint16_t seq;                  /* ARQ frame sequence number */
    uint8_t  payload[43];         /* MAVLink payload (21-43 bytes) */
    uint8_t  payload_len;         /* payload length */
    uint8_t  acked;               /* 1 = acknowledged, 0 = not yet */
    uint8_t  retries;             /* retransmission count */
} arq_frame_t;

typedef struct {
    arq_state_t state;             /* current ARQ state (TX or RX side) */
    uint16_t    tx_seq;            /* next TX frame sequence number */
    uint16_t    rx_expected_seq;  /* next frame sequence RX expects */
    uint16_t    last_ack_seq;      /* last sequence number ACK'd by RX (TX side) */
    uint16_t    batch_seq;         /* current batch sequence (group seq in MAC header) */
    uint8_t     batch_size;        /* number of frames per batch */
    uint8_t     frames_in_batch;   /* how many frames in current batch */
    arq_frame_t tx_window[256];    /* send window (max 256 frames buffered) */
    uint16_t    tx_window_head;    /* head of send window (frames waiting to be acked) */
    uint16_t    tx_window_tail;    /* tail (oldest unacked frame) */
    uint16_t    tx_window_count;   /* number of frames in window */
    uint8_t     rx_batch_frames[256];  /* received MAVLink payloads in current batch */
    uint16_t    rx_batch_seqs[256];    /* their sequence numbers */
    uint16_t    rx_batch_count;        /* how many frames received in current batch */
    uint16_t    rx_last_delivered_seq;  /* last sequence number delivered to UART */
    uint8_t     rx_last_delivered_len;  /* length of last delivered frame */
    uint8_t     rx_batch_complete;      /* flag: batch complete, ready to send ACK */
    uint32_t    ack_timeout_ticks;      /* countdown for ACK timeout */
    uint8_t     tx_retry_count;          /* retransmission count for current batch */
    uint16_t    missing_frame_seqs[16]; /* missing frame seqs (for NACK) */
    uint8_t     missing_count;           /* how many missing */
    uint8_t    side;                      /* 0=TX side, 1=RX side (set by node ID) */
} arq_state_t;

static arq_state_t arq = {0};

/* ============================================================================
 * ARQ initialization
 * ============================================================================ */
void arq_manager_init(void) {
    memset(&arq, 0, sizeof(arq));
    arq.state          = ARQ_TX_IDLE;
    arq.tx_seq          = 0;
    arq.rx_expected_seq = 0;
    arq.last_ack_seq    = 0;
    arq.batch_seq       = 0;
    arq.batch_size      = CONFIG_ARQ_BATCH_SIZE;
    arq.tx_window_head  = 0;
    arq.tx_window_tail  = 0;
    arq.tx_window_count = 0;
    arq.rx_batch_count  = 0;
    arq.rx_last_delivered_seq = 0;
    arq.rx_batch_complete = 0;
    arq.ack_timeout_ticks = 0;
    arq.tx_retry_count  = 0;
    arq.missing_count  = 0;

    /* Determine side based on node ID */
    if (CONFIG_THIS_NODE_ID == CONFIG_TARGET_NODE_ID) {
        /* Should not happen — each node has unique ID */
        arq.side = 0;
    } else {
        /* This node's ID vs target node ID */
        /* For TX side: this_node sends to target_node */
        /* For RX side: this_node receives from target_node (which sends to this_node) */
        /* The RX node is the one whose node ID matches the target of incoming packets */
        arq.side = 0;  /* Default: TX side. The MAC layer determines RX/TX based on packet headers. */
    }

    diag.arq_total_batches_tx = 0;
    diag.arq_total_batches_rx = 0;
    diag.arq_retransmissions  = 0;
    diag.arq_acks_sent        = 0;
    diag.arq_acks_received    = 0;
    diag.arq_nacks_sent       = 0;
    diag.dropped_duplicates   = 0;
}

/* ============================================================================
 * ARQ TX side — called when MAVLink frame arrives from UART
 * ============================================================================ */
int arq_tx_push_frame(const uint8_t *mavlink_payload, uint8_t mavlink_len) {
    /*
     * Push a MAVLink frame into the ARQ send window.
     * The frame will be included in the next batch.
     *
     * Returns 0 on success, -EINVAL if window full, -EAGAIN if TX busy.
     */
    if (arq.state != ARQ_TX_IDLE && arq.state != ARQ_TX_BUILDING) {
        return -EAGAIN;  /* TX side is busy (TX'ing or waiting for ACK) */
    }

    if (arq.tx_window_count >= 256) {
        return -EINVAL;  /* window full */
    }

    arq_frame_t *frame = &arq.tx_window[arq.tx_window_tail];

    if (mavlink_len > sizeof(frame->payload)) {
        return -EINVAL;
    }

    frame->seq          = arq.tx_seq++;
    frame->payload_len  = mavlink_len;
    frame->acked        = 0;
    frame->retries      = 0;
    memcpy(frame->payload, mavlink_payload, mavlink_len);

    arq.tx_window_tail = (arq.tx_window_tail + 1) % 256;
    arq.tx_window_count++;

    diag.arq_frames_queued++;

    return 0;
}

/* ============================================================================
 * ARQ TX side — called when batch TX is complete (TxDone callback)
 * ============================================================================ */
void arq_tx_batch_complete(void) {
    /*
     * The entire batch has been TX'd. Switch to RX mode and wait for ACK.
     */
    arq.state = ARQ_TX_WAITING_ACK;
    arq.ack_timeout_ticks = CONFIG_ARQ_ACK_TIMEOUT_MS / 100;  /* 100 ms timer period */
    diag.arq_total_batches_tx++;
}

/* ============================================================================
 * ARQ TX side — called when ACK received from RX
 * ============================================================================ */
void arq_tx_on_ack(uint16_t ack_seq) {
    /*
     * ACK received: all frames with seq ≤ ack_seq are acknowledged.
     * Remove acknowledged frames from the send window.
     * If all frames in window are acked → go back to IDLE and start next batch.
     * If some frames are still unacked → go back to BUILDING and retransmit.
     */
    arq.state = ARQ_TX_IDLE;

    /* Remove acked frames from window */
    while (arq.tx_window_count > 0) {
        arq_frame_t *frame = &arq.tx_window[arq.tx_window_head];

        if (frame->seq <= ack_seq) {
            /* This frame is acknowledged — remove from window */
            frame->acked = 1;
            arq.tx_window_head = (arq.tx_window_head + 1) % 256;
            arq.tx_window_count--;
            diag.arq_frames_acked++;
        } else {
            /* This frame is not yet acked — stop removing */
            break;
        }
    }

    /* Update last ack seq */
    if (ack_seq > arq.last_ack_seq) {
        arq.last_ack_seq = ack_seq;
    }

    /* Start next batch if there are frames waiting */
    if (arq.tx_window_count > 0) {
        diag.arq_retransmissions += arq.tx_window_count;  /* these are retransmissions */
        /* Go to BUILDING state (will be triggered by arq_build_next_batch) */
    } else {
        /* All frames acked — back to IDLE */
        arq.state = ARQ_TX_IDLE;
    }

    diag.arq_acks_received++;
}

/* ============================================================================
 * ARQ TX side — called when ACK timeout expires
 * ============================================================================ */
void arq_tx_on_ack_timeout(void) {
    /*
     * No ACK received within timeout. Retransmit unacknowledged frames.
     */
    if (arq.tx_window_count > 0) {
        arq.tx_retry_count++;
        diag.arq_retransmissions += arq.tx_window_count;

        /* Go to BUILDING state to retransmit */
        arq.state = ARQ_TX_IDLE;  /* will be set to BUILDING by arq_build_next_batch */
    } else {
        /* No frames to retransmit — back to IDLE */
        arq.state = ARQ_TX_IDLE;
    }

    if (arq.tx_retry_count > CONFIG_ARQ_MAX_RETRIES) {
        /* Max retries exceeded — drop the batch, log error */
        /* Clear the window */
        arq.tx_window_head = arq.tx_window_tail;
        arq.tx_window_count = 0;
        arq.tx_retry_count = 0;
        arq.state = ARQ_TX_IDLE;
        diag.arq_max_retries_exceeded++;
    }
}

/* ============================================================================
 * ARQ TX side — build and send next batch
 * ============================================================================ */
int arq_build_and_send_batch(void) {
    /*
     * Build a batch from the send window and TX it over LoRa.
     *
     * This function:
     *   1. Collects up to batch_size frames from the window
     *   2. Builds LoRa packets (MAC header + MAVLink payload) for each frame
     *   3. TXs each packet over LoRa
     *   4. On batch complete, sets state to WAITING_ACK
     *
     * Returns 0 on success, -EAGAIN if not enough frames or TX busy.
     */
    if (arq.tx_window_count == 0) {
        return -EAGAIN;  /* no frames to send */
    }

    if (arq.state != ARQ_TX_IDLE && arq.state != ARQ_TX_BUILDING) {
        return -EAGAIN;  /* TX side is busy */
    }

    arq.state = ARQ_TX_TXING;
    arq.batch_seq++;  /* increment group sequence for this batch */
    arq.frames_in_batch = 0;

    /* Collect up to batch_size frames from the window */
    uint16_t batch_frames[CONFIG_ARQ_BATCH_SIZE];
    uint8_t  batch_payloads[CONFIG_ARQ_BATCH_SIZE][43];
    uint8_t  batch_payload_lens[CONFIG_ARQ_BATCH_SIZE];
    uint16_t batch_count = 0;

    uint16_t idx = arq.tx_window_head;
    for (uint8_t i = 0; i < CONFIG_ARQ_BATCH_SIZE && arq.tx_window_count > 0; i++) {
        arq_frame_t *frame = &arq.tx_window[idx];

        batch_frames[batch_count]      = frame->seq;
        batch_payload_lens[batch_count] = frame->payload_len;
        memcpy(batch_payloads[batch_count], frame->payload, frame->payload_len);

        batch_count++;
        idx = (idx + 1) % 256;
    }

    /* TX each frame in the batch */
    for (uint8_t i = 0; i < batch_count; i++) {
        uint8_t lora_payload[51];  /* max MAC frame: 8 header + 43 payload = 51 bytes */
        int lora_len = mac_build_data_frame(lora_payload, sizeof(lora_payload),
                                            arq.batch_seq,
                                            batch_frames[i],
                                            batch_payloads[i],
                                            batch_payload_lens[i],
                                            CONFIG_THIS_NODE_ID,
                                            CONFIG_TARGET_NODE_ID);

        if (lora_len < 0) {
            continue;
        }

        /* TX the LoRa packet */
        lora_phy_tx(lora_payload, (uint16_t)lora_len);

        /* Wait for TxDone before sending next packet (half-duplex) */
        /* The loraphy_event_thread manages this waiting */
        arq.state = ARQ_TX_TXING;

        /* Wait for TxDone callback (blocks here) */
        k_sem_take(&sem_lora_tx_done, K_FOREVER);

        diag.mac_frames_tx++;
        diag.mac_bytes_tx += lora_len;
    }

    /* Batch complete — switch to RX mode and wait for ACK */
    arq.tx_batch_complete();
    arq.frames_in_batch = batch_count;

    /* Switch LoRa to RX mode */
    lora_phy_rx_start();

    return 0;
}

/* ============================================================================
 * ARQ RX side — called when LoRa RX packet received
 * ============================================================================ */
void arq_rx_on_packet(const uint8_t *lora_payload, uint16_t lora_len) {
    /*
     * A LoRa packet has been received (passed LoRa CRC).
     * Parse the MAC frame and process based on frame type.
     */
    mac_frame_t frame;
    int rc = mac_parse_frame(lora_payload, lora_len, &frame);
    if (rc != 0) {
        diag.mac_frames_parse_error++;
        return;
    }

    /* Log RSSI/SNR for this packet */
    int16_t rssi = lora_phy_get_last_rssi();
    int8_t  snr  = lora_phy_get_last_snr();
    diag.rssi_samples++;
    diag.rssi_sum += rssi;
    if (snr > diag.snr_min) {
        diag.snr_min = snr;
    }

    if (frame.frame_type == MAC_FRAME_TYPE_DATA) {
        /*
         * Data frame — process the MAVLink payload.
         */
        if (frame.tx_node_id != CONFIG_TARGET_NODE_ID) {
            /* Not from the expected TX node — discard */
            diag.mac_frames_wrong_src++;
            return;
        }

        /* Check for duplicate (seq ≤ last_delivered_seq) */
        if (frame.frame_sequence <= arq.rx_last_delivered_seq) {
            /* Duplicate — skip (don't deliver to UART, don't count) */
            diag.dropped_duplicates++;
            diag.mac_frames_rx_duplicate++;
            return;
        }

        /* Sequence gap detection */
        if (frame.frame_sequence > arq.rx_expected_seq) {
            /*
             * Gap detected — some frames are missing between expected and received.
             * Track the missing frames for NACK.
             */
            uint16_t gap = frame.frame_sequence - arq.rx_expected_seq;
            if (gap > 1) {
                /* Mark missing frames (up to 16) */
                for (uint16_t s = arq.rx_expected_seq + 1;
                     s < frame.frame_sequence && arq.missing_count < 16;
                     s++) {
                    arq.missing_frame_seqs[arq.missing_count++] = s;
                    diag.mac_frames_missing++;
                }
            }
        }

        /* Update expected sequence */
        arq.rx_expected_seq = frame.frame_sequence + 1;

        /* Deliver the MAVLink payload to UART (for Python logger capture) */
        uart_dma_push_frame(frame.payload, frame.payload_len);

        /* Track delivered frame */
        arq.rx_last_delivered_seq = frame.frame_sequence;
        arq.rx_batch_frames[arq.rx_batch_count] = frame.frame_sequence;
        arq.rx_batch_seqs[arq.rx_batch_count]    = frame.frame_sequence;
        arq.rx_batch_count++;

        diag.mac_frames_rx++;
        diag.mac_bytes_rx += lora_len;
        diag.mavlink_frames_delivered++;

        /* If batch is full (reached batch_size), mark complete */
        if (arq.rx_batch_count >= CONFIG_ARQ_BATCH_SIZE) {
            arq.rx_batch_complete = 1;
        }
    } else if (frame.frame_type == MAC_FRAME_TYPE_ACK) {
        /*
         * ACK frame from TX node (this node is the RX node, receiving ACK???)
         * Actually, the ACK is sent FROM the RX node TO the TX node.
         * This RX side is the one that SENDS ACKs, not receives them.
         * If we receive an ACK here, it means this node is the TX side
         * (the other node is acknowledging our TX batch).
         */
        if (frame.tx_node_id == CONFIG_TARGET_NODE_ID &&
            frame.rx_node_id == CONFIG_THIS_NODE_ID) {
            /* ACK from the other node — this node is the TX side */
            arq_tx_on_ack(frame.group_sequence);  /* use frame_sequence as ack_seq */
        }
    } else if (frame.frame_type == MAC_FRAME_TYPE_NACK) {
        /* NACK frame — selective retransmission request */
        if (frame.tx_node_id == CONFIG_TARGET_NODE_ID &&
            frame.rx_node_id == CONFIG_THIS_NODE_ID) {
            /* NACK from the other node — this node is the TX side */
            /* Extract missing frame sequences and retransmit them */
            uint8_t missing_count = frame.payload[6];  /* missing count in NACK header */
            for (uint8_t i = 0; i < missing_count && i < 16; i++) {
                uint16_t missing_seq = (uint16_t)frame.payload[MAC_HEADER_SIZE + 2*i] |
                                       ((uint16_t)frame.payload[MAC_HEADER_SIZE + 2*i + 1] << 8U);
                arq.missing_frame_seqs[arq.missing_count++] = missing_seq;
            }
            /* Retransmit missing frames */
            arq.state = ARQ_TX_IDLE;  /* trigger retransmission */
        }
    } else if (frame.frame_type == MAC_FRAME_TYPE_END) {
        /* End-of-batch marker — batch is complete, send ACK */
        arq.rx_batch_complete = 1;
    }
}

/* ============================================================================
 * ARQ RX side — called when batch is complete
 * ============================================================================ */
void arq_rx_batch_complete(void) {
    /*
     * The RX batch is complete (either by batch_size reached or RX timeout).
     * Build and send ACK to the TX node.
     */
    arq.rx_batch_complete = 0;

    /* Determine last received frame sequence in this batch */
    uint16_t last_seq = 0;
    if (arq.rx_batch_count > 0) {
        last_seq = arq.rx_batch_seqs[arq.rx_batch_count - 1];
    } else {
        last_seq = arq.rx_last_delivered_seq;
    }

    /* Build ACK frame */
    uint8_t ack_buffer[8];  /* ACK frame is just the MAC header (no payload) */
    int ack_len = mac_build_ack_frame(ack_buffer, sizeof(ack_buffer),
                                      arq.batch_seq,
                                      last_seq,
                                      CONFIG_THIS_NODE_ID,   /* TX side's node ID (who sends ACK) */
                                      CONFIG_TARGET_NODE_ID); /* RX side's node ID (who receives ACK) */

    if (ack_len > 0) {
        /* TX the ACK packet over LoRa */
        lora_phy_tx(ack_buffer, (uint16_t)ack_len);
        diag.arq_acks_sent++;
        diag.mac_frames_ack_tx++;

        /* Wait for TxDone, then switch back to RX mode */
        arq.state = ARQ_RX_SENDING_ACK;
    }
}

/* ============================================================================
 * ARQ RX side — called when RX timeout (batch end detected)
 * ============================================================================ */
void arq_rx_on_timeout(void) {
    /*
     * RX timeout — no packet received for a while.
     * This indicates the TX batch has ended (TX node switched to RX).
     * Complete the batch and send ACK.
     */
    if (arq.rx_batch_count > 0 || arq.rx_last_delivered_seq > 0) {
        arq.rx_batch_complete = 1;
    }
}

/* ============================================================================
 * ARQ tick — called periodically (100 ms) for timeout handling
 * ============================================================================ */
void arq_tick(void) {
    /*
     * Periodic ARQ timeout handling.
     */
    if (arq.state == ARQ_TX_WAITING_ACK) {
        if (arq.ack_timeout_ticks > 0) {
            arq.ack_timeout_ticks--;
            if (arq.ack_timeout_ticks == 0) {
                /* ACK timeout — retransmit */
                arq_tx_on_ack_timeout();
            }
        }
    }
}

/* ============================================================================
 * ARQ state queries
 * ============================================================================ */
arq_state_t arq_get_state(void) {
    return arq.state;
}

uint16_t arq_get_tx_seq(void) {
    return arq.tx_seq;
}

uint16_t arq_get_rx_expected_seq(void) {
    return arq.rx_expected_seq;
}

uint16_t arq_get_last_ack_seq(void) {
    return arq.last_ack_seq;
}

uint16_t arq_get_window_count(void) {
    return arq.tx_window_count;
}
