# Sub-GHz MAVLink Bridge — Zephyr RTOS Port

**Target:** Nucleo-WL55JC1 × 2 (STM32WL55JC1, integrated SUBGHZ transceiver)  
**Link:** FSK @ 13.12 kbps, bidirectional UART ↔ RF bridge  
**Goal:** 5–7 km line-of-sight, **zero MAVLink frame loss**  
**Zephyr:** 3.x

---

## Table of Contents

1. [What this port provides](#what-this-port-provides)
2. [Current baseline vs. zero-loss target](#current-baseline-vs-zero-loss-target)
3. [Why you're seeing 72–81% delivery (root causes)](#why-youre-seeing-7281-delivery-root-causes)
4. [The three pillars of zero-loss 5–7 km operation](#the-three-pillars-of-zero-loss-57-km-operation)
5. [Link budget calculation for 5–7 km](#link-budget-calculation-for-57-km)
6. [Project structure](#project-structure)
7. [Build & flash](#build--flash)
8. [Node configuration (Node A vs. Node B)](#node-configuration-node-a-vs-node-b)
9. [MAVLink integration](#mavlink-integration)
10. [Validation with the Python logger](#validation-with-the-python-logger)
11. [Troubleshooting](#troubleshooting)

---

## What this port provides

This is a faithful Zephyr RTOS port of your validated STM32CubeWL + HAL Sub-GHz FSK bridge. It preserves the exact ring-buffer architecture, sequence tracking, and radio state machine that you already benchmarked, while wrapping it in Zephyr's proper concurrency primitives:

| Original (CubeHAL)             | Zephyr Port                            |
| ------------------------------- | --------------------------------------- |
| `UTIL_SEQ_RegTask` + `SetTask` | `k_thread_create` + `k_sem_give`      |
| `UTIL_TIMER_Create/Start`      | `k_timer_init` + `k_timer_start`      |
| `TX_RING_SIZE` / `RX_RING_SIZE` ring buffers | Same ring buffers (lock-free, PRIMASK CS) |
| `Radio.SetRxConfig` / `SetTxConfig` / `Send` / `Rx` | Same ST RF HAL calls (or Zephyr `subghz_*` API — see below) |
| `HAL_UART_Receive_DMA` circular | Same HAL call, or Zephyr `uart_` + DMA API |
| `RX_TIMEOUT_VALUE` / `TX_TIMEOUT_VALUE` | Same constants (Kconfig-adjustable) |

**Two porting backends are supported** (select via `RF_HAL_BACKEND` in `rf_halwrapper.h`):

- **A) STM32CubeWL HAL** (default): uses the ST RF HAL `Radio_*` API directly, same as your current code. Lowest risk, drop-in replacement for the RF layer. Zephyr provides thread/timer management; the HAL handles the RF peripheral.

- **B) Zephyr native SUBGHZ driver**: uses Zephyr's `subghz_configure()` / `subghz_transmit()` / `subghz_receive()` API. Cleaner Zephyr-native code but requires adapting the FSK parameter mapping to Zephyr's `subghz_config_t` structure.

---

## Current baseline vs. zero-loss target

From your logger data:

```
Run 1: TX=7410  RX=7399  delivery=72.3%  missing=13 frames
Run 2: TX= 955  RX= 952  delivery=81.5%  missing=  2 frames
```

**What this means:** you're losing 18–28% of frames over the air. At 13.12 kbps with a MAVLink stream that has heartbeat (msgid 0), sys_status (msgid 1), attitude (msgid 30), and global_position_int (msgid 33), a 72% delivery ratio means **nearly 1 in 3 MAVLink messages never arrives at the ground station.** For telemetry that is unacceptable; for a safety-critical drone link it's dangerous.

**The goal: 5–7 km with 0% loss.** This is achievable, but requires fixing the link layer AND the physical layer simultaneously. The three pillars are:

---

## Why you're seeing 72–81% delivery (root causes)

### 1. Physical layer: insufficient link margin at 5–7 km

At 13.12 kbps FSK, the theoretical minimum receiver sensitivity for a BPSK/FSK demodulator is:

```
Sensitivity (dBm) ≈ -174 + 10·log10(BW) + NF + EbN0_required
```

For FSK at 13.12 kbps with BW ≈ 12.5 kHz and NF ≈ 8 dB, and requiring Eb/N0 ≈ 8 dB for 10⁻⁵ BER:

```
Sensitivity ≈ -174 + 10·log10(12500) + 8 + 8
            ≈ -174 + 41 + 16
            ≈ -117 dBm   (theoretical best case)
```

Real-world ST27/STM32WL sensitivity at 13.12 kbps FSK is typically **-105 to -110 dBm** (with CRC, good SNR). Let's use **-107 dBm** as a realistic receiver sensitivity.

**Path loss at 5 km (free space, 868 MHz):**

```
PL(dB) = 20·log10(d) + 20·log10(f) - 147.55
       = 20·log10(5000) + 20·log10(868e6) - 147.55
       = 74.0 + 178.8 - 147.55
       = 105.3 dB
```

At 7 km:
```
PL(7km) = 20·log10(7000) + 178.8 - 147.55 = 108.9 dB
```

**Link budget with TX = +22 dBm, RX antenna = 0 dBi:**

```
RX power at 5 km = 22 - 105.3 + 0 = -83.3 dBm  → margin = 24 dB ✔
RX power at 7 km = 22 - 108.9 + 0 = -86.9 dBm  → margin = 20 dB ✔
```

**BUT:** this assumes free-space propagation. In practice:
- **Earth curvature**: at 5-7 km, LOS is achievable at moderate altitude but terrain matters
- **Foliage/obstacles**: even light foliage adds 10-20 dB loss
- **Antenna mismatch**: Nucleo-WL55 has a PCB antenna or SMA connector — poor matching costs 3-10 dB
- **Multipath**: reflective environments reduce effective SNR
- **Manhattan/free-space difference**: real range is often **15-30% less** than free-space prediction

**So the honest link budget for 7 km real-world is more like:**

```
RX power  = TX_power + TX_ant_gain + RX_ant_gain - path_loss - margin_required
          = 22 + 2 + 3 - 108.9 - 15 dB (safety margin for 0% loss)
          = -96.9 dBm   (with 15 dB fading margin)
```

With sensitivity -107 dBm, this gives only **10 dB margin** — not enough for zero packet loss in fading conditions. A **minimum 20-25 dB link margin** is needed for 0% loss at the packet level.

### 2. Protocol layer: no ACK/retry at the MAVLink level

Your current code is a **transparent bridge**: it forwards each UART byte as an RF packet, and each RF packet to UART. There is **no reliability mechanism** at the MAVLink layer — if an RF packet is corrupted in flight, the MAVLink frame inside it is lost forever. MAVLink itself has a **sequence number** (the `seq` field in the MAVLink header) and a CRC (X.25), so the receiver CAN detect corruption, but your bridge code doesn't retransmit on CRC failure.

### 3. Modulation/parameter mismatch

The `FSK_BANDWIDTH = 12500` and `FSK_FDEV = 5000` settings determine the modulation quality. The **deviation ratio** is:

```
deviation_ratio = FDEV / datarate = 5000 / 13120 = 0.38
```

This is a **narrow-deviation FSK** (well-suited for low bandwidth). However, the **bandwidth-to-datarate ratio** is:

```
BW / datarate = 12500 / 13120 = 0.95
```

A ratio of 0.95 means the receiver bandwidth is approximately equal to the data rate — this is **correct for minimum-shift keying (MSK) / Gaussian FSK** but tight for plain FSK. If your settings don't exactly match the ST RF HAL's expected values, the BER will be higher than theoretical.

**The settings in your code are close to correct for 13.12 kbps FSK**, but verify against the ST RF HAL documentation for your exact part.

---

## The three pillars of zero-loss 5–7 km operation

### Pillar 1: Maximize the physical link margin

| Parameter               | Current (assumed) | Recommended for 5-7 km zero-loss | Impact |
| ------------------------| ------------------ | --------------------------------- | ------ |
| TX power                | ~+15 to +22 dBm  | **+22 dBm** (max for STM32WL)    | +7-10 dB range |
| TX antenna              | PCB antenna (~0 dBi) | **2-3 dBi gain** (whip/helix) | +2-3 dB |
| RX antenna (ground)     | PCB antenna (~0 dBi) | **5-8 dBi gain** (Yagi/directional) | +5-8 dB |
| Frequency               | 868 MHz (assumed) | **433 MHz** (if allowed in region) | +6-8 dB range at same power (lower freq → less path loss) |
| RX bandwidth            | 12500 Hz           | **8000-10000 Hz** (match to datarate) | Better SNR, -2 to -3 dB sensitivity improvement |
| Implementation margin  | 0 dB               | **15-20 dB** (fading margin)      | For 0% loss |

With a **directional Yagi on the ground station (6 dBi)** and **+22 dBm TX**, the effective link margin at 7 km improves dramatically:

```
TX_power = 22 dBm
TX_ant   = 3 dBi (whip on drone)
RX_ant   = 6 dBi (Yagi at ground station)
Path_loss(7km, 868MHz) = 108.9 dB
Fading margin         = 15 dB
--------------------------------------------------
RX_power = 22 + 3 + 6 - 108.9 - 15 = -92.9 dBm
Sensitivity = -107 dBm
Link margin = 14.1 dB  → still tight for 0% loss
```

**To get 25 dB margin at 7 km**, you need either:
- **Lower frequency (433 MHz)**: path loss drops to ~100 dB → RX = -84 dBm → margin = 23 dB ✔
- **Higher TX power**: STM32WL maxes at +22 dBm; external PA needed for more
- **Higher antenna gain on both ends**: +3 dBi TX + +8 dBi RX = 11 dB additional → margin = 25 dB ✔
- **Shorter range or LOS guarantee**: reduce to 5 km with 20 dB margin

**Recommendation:** Use **433 MHz** (if region permits) OR **+22 dBm + 5-8 dBi directional RX antenna** and aim for **5 km** as the reliable range. For 7 km, you need favorable LOS conditions plus high-gain RX antenna.

### Pillar 2: Add MAVLink-level reliability (ACK + sequence gap detection)

The bridge as-is is transparent. To achieve zero *MAVLink* loss, add a reliability layer:

**Option A: Selective repeat ARQ (recommended for telemetry)**

At the TX side (drone):
1. Buffer the last N MAVLink frames (e.g., N=10)
2. Include a **per-frame sequence number** (already in MAVLink)
3. After sending a frame over RF, **wait for an ACK** from the RX side
4. If no ACK within timeout, **retransmit** the same frame
5. At the RX side: on receiving a frame, send back an ACK frame (a small RF packet with the seq number)

**Option B: SEQ tracking + retransmission request**

At the RX side (ground station):
1. Track the expected MAVLink sequence number (from `seq` field in MAVLink header)
2. If a gap is detected (expected_seq != received_seq), send a **RETRANSMIT_REQUEST** frame back over RF
3. The TX side re-sends the missing frame(s) from its buffer

**Option C: FEC (Forward Error Correction)**

For a stream that cannot tolerate ACK latency, add FEC encoding (e.g., Reed-Solomon or LDPC) before putting MAVLink frames into the RF packet. At 13.12 kbps with 64-byte payload, you can afford ~8 bytes of parity per packet for robust FEC.

**Option D: Lower the effective TX rate to reduce collision/congestion**

At 13.12 kbps with ~35-byte average MAVLink frames, you're sending ~47 packets/second. If both nodes TX simultaneously (half-duplex), there's a collision risk. Consider:
- **TDMA**: Alternate TX windows between nodes
- **Lower rate**: Send MAVLink frames at a lower rate (e.g., only send attitude at 10 Hz instead of 47 Hz) to reduce airtime occupancy

### Pillar 3: Optimize the RF parameters for your specific link

| Parameter | Current | Recommended | Rationale |
|-----------|---------|-------------|-----------|
| `FSK_DATARATE` | 13120 | 13120 (target) | Fixed by MAVLink stream requirement |
| `FSK_FDEV` | 5000 | **5200-5400** | Slightly wider deviation improves immunity to frequency errors; check ST RF HAL recommended values for 13.12 kbps |
| `FSK_BANDWIDTH` | 12500 | **10000-12500** | Match to datarate; narrower = better sensitivity but requires freq accuracy |
| `FSK_AFC_BANDWIDTH` | 83333 | **83333** (keep) | AFC helps with frequency drift; keep at current |
| `FSK_PREAMBLE_LENGTH` | 3 | **3-4** | Short preamble reduces overhead; adequate for FSK with good sync |
| `TX_TIMEOUT_VALUE` | 1000 | **1500-2000** | Increase to handle retransmissions at 5-7 km (longer airtime per frame) |
| `RX_TIMEOUT_VALUE` | 100 | **150-200** | Longer RX window improves capture of weakly received packets |
| `TX_OUTPUT_POWER` | 22 (assumed) | **22** | Maximum legal in most regions; verify your frequency band |

**To verify your settings**: use the ST RF HAL's `Radio.GetRxStats()` or similar to read RSSI/SNR on the RX side during a test. If the SNR is below ~10 dB at your target range, the link is marginal and you need to improve the physical layer.

---

## Link budget calculation for 5–7 km

See the [Link Budget Calculator](docs/link_budget.md) (or use this inline):

```
FREQUENCY: 868 MHz (EU ISM) — or 433 MHz for better range
TX_POWER:  +22 dBm (STM32WL max)
TX_ANT:    +3 dBi (¼-wave whip on Nucleo)
RX_ANT:    +6 dBi (Yagi at ground station)
RX_SENS:   -107 dBm (realistic FSK @ 13.12 kbps, CRC, SNR>10dB)
MARGIN:    20 dB (required for 0% packet loss in fading)

PATH_LOSS(5km, 868MHz) = 105.3 dB
RX_PWR = 22 + 3 + 6 - 105.3 - 20 = -94.3 dBm
MARGIN = -94.3 - (-107) = 12.7 dB  → GOOD for 5 km ✔

PATH_LOSS(7km, 868MHz) = 108.9 dB
RX_PWR = 22 + 3 + 6 - 108.9 - 20 = -97.9 dBm
MARGIN = -97.9 - (-107) = 9.1 dB   → MARGINAL for 7 km ⚠

PATH_LOSS(7km, 433MHz) = 101.5 dB
RX_PWR = 22 + 3 + 6 - 101.5 - 20 = -90.5 dBm
MARGIN = -90.5 - (-107) = 16.5 dB  → GOOD for 7 km at 433 MHz ✔
```

**Bottom line:** With a +22 dBm TX, 3 dBi TX antenna, and 6 dBi RX antenna:
- **5 km at 868 MHz**: margin ≈ 13 dB → **reliable, zero-loss achievable** ✔
- **7 km at 868 MHz**: margin ≈ 9 dB → **marginal, expect occasional loss without ACK/FEC** ⚠
- **7 km at 433 MHz**: margin ≈ 17 dB → **reliable, zero-loss achievable** ✔

---

## Project structure

```
subghz_mavlink_bridge/
├── project.conf                      # Zephyr application configuration
├── CMakeLists.txt                    # Build definition; add STM32CubeWL sources here
├── Kconfig                           # User-configurable parameters (node ID, RF params, etc.)
├── subghz_mavlink_bridge.overlay     # Device tree overlay (UART2, DMA, SUBGHZ)
├── include/
│   ├── subghz_mavlink_bridge.h       # Public API + configuration macros
│   └── rf_halwrapper.h               # ST RF HAL abstraction (STM32CubeWL or Zephyr SUBGHZ)
└── src/
    ├── main.c                        # Zephyr entry point; HAL init; thread creation
    └── subghz_mavlink_bridge.c       # Bridge core: threads, rings, radio state machine,
                                       #   UART DMA, frame encoding/decoding, diagnostics
```

---

## Build & flash

```bash
# Prerequisites: Zephyr SDK, west, Python 3.x, pip install mavlink (for logger)

# 1. Set up Zephyr workspace (if not already done)
cd ~/zephyrproject
west init -l <your-manifest-url>
west update
pip install -r zephyr/scripts/requirements.txt

# 2. Build for Nucleo-WL55JC1
cd subghz_mavlink_bridge
west build -b nucleo_wl55jc1 --clean

# If nucleo_wl55jc1 board is not in your Zephyr tree, add it or use:
#   west build -b nucleo_wl55jc1 --board-dir /path/to/custom/board

# 3. Flash
west flash

# 4. For Node B (ground station), rebuild with different node IDs:
#   In project.conf or via Kconfig:
#     CONFIG_THIS_NODE_ID=2  CONFIG_TARGET_NODE_ID=1  CONFIG_PEER_NODE_ID=1
```

**If your Zephyr version does not include `nucleo_wl55jc1` as a board:**
- Add the board DTS files to your Zephyr tree under `boards/arm/nucleo_wl55jc1/`
- Or use a close alternative board and override with the `.overlay` file

**STM32CubeWL HAL integration** (Option A in `rf_halwrapper.h`):
- Add the STM32CubeWL firmware package to your Zephyr project as a module or as source files
- Include `STM32CubeWL/RF/inc/` and `STM32CubeWL/Utilities/inc/` in `target_include_directories`
- Add the required `.c` files from `STM32CubeWL/RF/src/` and `STM32WLxx_HAL_Driver/Src/` to `target_sources`

---

## Node configuration (Node A vs. Node B)

Each Nucleo board must have a **unique node ID**. Build two separate binaries:

### Node A — Airbone / Flight Controller side
```kconfig
CONFIG_THIS_NODE_ID    = 1   # 0x01
CONFIG_TARGET_NODE_ID  = 2   # 0x02 (sends to ground)
CONFIG_PEER_NODE_ID    = 2   # 0x02 (accepts from ground)
```

### Node B — Ground station side
```kconfig
CONFIG_THIS_NODE_ID    = 2   # 0x02
CONFIG_TARGET_NODE_ID  = 1   # 0x01 (sends to airborne)
CONFIG_PEER_NODE_ID    = 1   # 0x01 (accepts from airborne)
```

These can be set via:
- `project.conf`: `CONFIG_THIS_NODE_ID=1`
- Kconfig menuconfig: `west build -t menuconfig`
- Device tree property on the specific board DTS

---

## MAVLink integration

The bridge connects to the flight controller (FC) via UART2 on each Nucleo:

```
[FC] ──UART2── [Nucleo A] ──RF FSK── [Nucleo B] ──UART2── [Ground Station / PC]
```

**What the bridge does:**
1. **UART2 RX** (from FC) → tx_ring → RF TX frame
2. **RF RX** → rx_ring → UART2 TX (to ground station)

**What the Python logger does:**
- `TX mode`: sends synthetic MAVLink2 frames at 13.12 kbps to the TX Nucleo's UART2, and logs each frame with its SHA-16 hash
- `RX mode`: reads binary MAVLink from the RX Nucleo's UART2 (which forwards RF→UART), reassembles MAVLink2 0xFD frames, logs them
- `compare`: matches TX log vs. RX log by SHA-16 hash to compute delivery ratio

**To use with a real flight controller:**
- Connect FC's TELEM port to Nucleo A's USART2 (PA2/PA3)
- Connect Nucleo B's USART2 to ground station (microcontroller, SiK radio, or PC via USB-UART)
- The bridge forwards FC telemetry over RF transparently
- The RF-side reliability (ACK/Retry/FEC) must be added at the MAVLink layer or as a higher-level protocol

**MAVLink frame format used in this bridge:**
```
[0xFD] [plen] [incompat_flags] [compat_flags] [seq] [sysid] [compid] [msgid_24] [payload...] [CRC16_LE]
```
- STX = 0xFD (MAVLink2)
- Sequence number: `seq` field in MAVLink header (0-255, wraps)
- Payload: the MAVLink message body
- CRC16: X.25 CRC over header+payload (MAVLink2 spec)

---

## Validation with the Python logger

Your existing logger (`mavlink_both_ends_logger.py`) is the right tool for validation. The Zephyr port produces identical output at the UART/byte level, so the same comparison methodology applies.

**Test procedure:**

```bash
# On PC, two COM ports (one per Nucleo):
# Terminal A: TX Nucleo on COM8
# Terminal B: RX Nucleo on COM7

# Start TX (sends MAVLink2 at 13.12 kbps, logs to file)
python mavlink_both_ends_logger.py tx --port COM8 --baud 115200 --bps 13120 --log-dir logs

# Start RX (reads from RX Nucleo UART, logs to file)
python mavlink_both_ends_logger.py rx --port COM7 --baud 115200 --log-dir logs

# After 5+ minutes of capture (at 47 pkt/s, 5 min = ~14,000 frames):
python mavlink_both_ends_logger.py compare \
    --tx-log logs/tx_20260717_XXXXXX.jsonl \
    --rx-log logs/rx_20260717_XXXXXX.jsonl
```

**Expected result after zero-loss fixes:**

```
TX frames: 14100  from logs\tx_...jsonl
RX frames: 14100  from logs\rx_...jsonl
RX sha matched to some TX: 14100 (events)
Unique TX frames seen on RX: 14100 / 14100
Delivery ratio (unique): 100.0%
Missing TX frames: 0
```

**If delivery is still below 100%**: use `--show-missing` to see which sequence numbers were lost, and correlate with RSSI/SNR readings from the RX Nucleo (if available via diagnostic output).

---

## Troubleshooting

### Issue: `west build` fails — board not found
**Fix:** Check `west boards | grep wl`. If `nucleo_wl55jc1` is not listed, either:
- Use a generic STM32WL board DTS and override with `.overlay`
- Add the Nucleo board definition from the Zephyr board YAML

### Issue: Radio doesn't transmit
**Fix:** Verify the STM32CubeWL HAL init sequence is correct. The `Radio.Init()` call requires the STM32WL RF peripheral to be clocked and configured. In Zephyr, ensure `CONFIG_STM32_RADIO` or equivalent is enabled.

### Issue: UART RX DMA not filling the buffer
**Fix:** Check that the UART2 IDLE interrupt is enabled (`UART_IT_IDLE`) and that the DMA stream for USART2 RX is correctly mapped in the device tree / HAL init. The `UART_RF_StartDmaRx()` function must be called after `HAL_UART_Receive_DMA()`.

### Issue: Delivery ratio improved but not 100%
**Fix:** This is a link margin problem, not a software problem. Improve:
- TX power (confirm +22 dBm is achieved; measure with a power meter)
- RX antenna gain (use a directional antenna)
- Frequency (try 433 MHz if allowed)
- Add MAVLink-level ACK/Retry (Pillar 2)

### Issue: MAVLink frames arriving with wrong seq / CRC errors
**Fix:** Check that the RF frame format matches the logger's expectations. The bridge adds an 8-byte RF header before the MAVLink payload. The logger's `MavLink2Reassembler` expects raw 0xFD MAVLink frames on the UART. If the RX Nucleo forwards the RF payload (including the 8-byte RF header) to UART, the logger will fail to parse. Ensure the RX firmware forwards only the **MAVLink payload** (bytes after the RF header) to UART2 TX.

---

## File manifest

```
subghz_mavlink_bridge/
├── project.conf                      # Zephyr app config
├── CMakeLists.txt                    # Build file (add STM32CubeWL sources)
├── Kconfig                           # User-configurable parameters
├── subghz_mavlink_bridge.overlay     # Device tree overlay (UART2, DMA, clocks)
├── include/
│   ├── subghz_mavlink_bridge.h       # Public API header
│   └── rf_halwrapper.h               # ST RF HAL abstraction layer
└── src/
    ├── main.c                        # Zephyr entry point
    └── subghz_mavlink_bridge.c       # Bridge core implementation
```

---

*Zephyr RTOS port of the validated STM32CubeWL Sub-GHz FSK bridge for Nucleo-WL55JC1. Target: 5-7 km MAVLink telemetry at 13.12 kbps with zero frame loss.*
