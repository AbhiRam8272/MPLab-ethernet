#ifndef SUBGHZ_MAVLINK_BRIDGE_H
#define SUBGHZ_MAVLINK_BRIDGE_H

/**
 * Sub-GHz MAVLink Bridge — Zephyr RTOS port header
 * -----------------------------------------------------------
 * Target: Nucleo-WL55JC1 (STM32WL55JC1, Sub-GHz transceiver integrated)
 * Link:   FSK @ 13.12 kbps, bidirectional UART <-> RF bridge
 * RF API: ST RF HAL (STM32CubeWL Radio API) — wrapped per Zephyr platform
 *
 * API exposed to the application (main.c or MAVLink layer):
 *   subghz_bridge_init()   — one-time init, spawns threads, opens radio
 *   subghz_tx_byte(b)     — push one byte into TX ring (call from UART RX ISR)
 *   subghz_rx_avail()     — returns true if RF→UART ring has data
 *   subghz_rx_read(buf,n) — read up to n bytes from RF→UART ring
 *   subghz_diag()         — pointer to live diagnostic counters struct
 *
 * Note: The Radio callbacks (OnTxDone, OnRxDone, etc.) fire from ISR context
 * and post events to the Zephyr thread queue. All application logic runs in
 * thread context.
 */

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

/* ---------------------------------------------------------------------------
 * Configuration macros — match the validated STM32CubeWL parameters
 * ---------------------------------------------------------------------------
 * These must be identical on both nodes. Adjust for your region/channel.
 */

/* Node addressing — set per board via Kconfig or device tree property */
#ifndef THIS_NODE_ID
#define THIS_NODE_ID       0x01U   /* Node A (airborne) — change to 0x02 on Node B */
#endif
#ifndef TARGET_NODE_ID
#define TARGET_NODE_ID     0x02U   /* Who we are transmitting to */
#endif
#ifndef PEER_NODE_ID
#define PEER_NODE_ID       0x02U   /* Expected sender; 0xFF = accept any */
#endif

/* Frame format (8-byte RF header + payload) */
#define MSG_TYPE_DATA      0x01U
#define SYNC_WORD_1        0xAAU
#define SYNC_WORD_2        0x55U
#define RF_MAX_PAYLOAD     64U      /* max user bytes per RF packet */
#define RF_HEADER_SIZE     8U       /* sync(2)+src(1)+dst(1)+type(1)+len(1)+seq(2) */
#define RF_MAX_FRAME       (RF_HEADER_SIZE + RF_MAX_PAYLOAD)

/* Ring sizes */
#define TX_RING_SIZE       2048U
#define RX_RING_SIZE       2048U
#define UART_DMA_BUF_SIZE  512U     /* STM32 DMA circular buffer window */

/* Radio timing (ms) */
#define RX_TIMEOUT_MS      100U
#define TX_TIMEOUT_MS      1000U
#define TX_RETRY_PERIOD_MS 10U

/* UART config — match CubeMX: USART2, 115200, parity none, 2 stop bits */
#define UART_BAUD_RATE     115200U
#define UART_PARITY        UART_PARITY_NONE
#define UART_STOP_BITS     UART_STOP_BITS_2

/* RF parameters — MUST match on both ends */
/* Define these in your Kconfig / device tree / board header per region */
#ifndef RF_FREQUENCY
#define RF_FREQUENCY       868000000U   /* Hz — 868 MHz EU band; use 433/915 per region */
#endif
#ifndef FSK_DATARATE
#define FSK_DATARATE       13120U       /* bps — the 13.12 kbps target */
#endif
#ifndef FSK_BANDWIDTH
#define FSK_BANDWIDTH      12500U       /* Hz — ~12.5 kHz for 13.12 kbps FSK */
#endif
#ifndef FSK_FDEV
#define FSK_FDEV           5000U        /* Hz — freq deviation; 5 kHz typical for 13k12 */
#endif
#ifndef FSK_AFC_BANDWIDTH
#define FSK_AFC_BANDWIDTH  83333U       /* Hz — AFC bandwidth */
#endif
#ifndef FSK_PREAMBLE_LENGTH
#define FSK_PREAMBLE_LENGTH 3U         /* preamble bytes — short for low latency */
#endif
#ifndef TX_OUTPUT_POWER
#define TX_OUTPUT_POWER    22          /* dBm — max on WL55 for range; verify region */
#endif

/* MAVLink integration */
#define MAVLINK_STX        0xFD
#define MAVLINK_MAX_FRAME  280   /* practical max for our link */

/* Sub-GHz HAL layer: we use the ST RF HAL from STM32CubeWL.
 * In a pure Zephyr SUBGHZ-driver port, replace rf_halwrapper.c with
 * Zephyr subghz API calls. See README for both options. */
#include "rf_halwrapper.h"   /* ST RF HAL Radio type, events, Init/SetRxConfig/SetTxConfig/Send/Sleep */

/* ---------------------------------------------------------------------------
 * Diagnostic counters (volatile, read via subghz_diag())
 * ---------------------------------------------------------------------------
 */
typedef struct {
    uint32_t tx_frame_count;          /* total frames constructed */
    uint32_t rx_frame_count;          /* total valid frames decoded */
    uint32_t tx_ring_overflow;
    uint32_t rx_ring_overflow;
    uint32_t tx_timeout_count;
    uint32_t rx_error_count;
    uint32_t invalid_frame_count;
    uint32_t rx_duplicate_count;
    uint32_t rx_sequence_loss;        /* missing sequence numbers detected */
    uint32_t uart_dma_overrun;
    uint32_t radio_event_overrun;
    uint32_t tx_retry_scheduled;
} subghz_diag_t;

/* ---------------------------------------------------------------------------
 * Public API
 * ---------------------------------------------------------------------------
 */
void subghz_bridge_init(void);
void subghz_tx_byte(uint8_t byte);   /* lock-free push; drops on full ring */
bool subghz_rx_avail(void);           /* true if RF->UART ring non-empty */
uint16_t subghz_rx_read(uint8_t *buf, uint16_t max_len);  /* drain ring */
const subghz_diag_t *subghz_diag(void);  /* pointer to live counters */

#endif /* SUBGHZ_MAVLINK_BRIDGE_H */
