#ifndef RF_HALWRAPPER_H
#define RF_HALWRAPPER_H

/*
 * rf_halwrapper.h — ST RF HAL (stm32wl radio) abstraction
 *
 * This header re-exposes the ST RF HAL types and functions so the bridge
 * code compiles against the STM32CubeWL HAL on Zephyr. If you switch to
 * Zephyr's native subghz driver, implement the same callbacks + API here.
 *
 * On Zephyr + STM32WL, the STM32 HAL is available; include:
 *   #include "stm32wlxx_hal.h"     (or your HAL variant)
 *   #include "radio.h"             (from STM32CubeWL firmware package)
 *   #include "stm32_seq.h"         (UTIL_SEQ task scheduler — or replace with Zephyr threads)
 *
 * For a pure-Zephyr port without STM32CubeWL firmware:
 *   - Replace Radio type with Zephyr subghz_context_t
 *   - Replace SetRxConfig/SetTxConfig/SetMaxPayloadLength/Send/Rx/Sleep
 *     with Zephyr subghz_configure() / subghz_transmit() / subghz_receive()
 *   - Replace UTIL_SEQ with Zephyr k_thread + k_sem
 *   - Replace HAL_UART_* with Zephyr uart_*
 *
 * This wrapper keeps the existing code structure intact.
 */

#include <stdint.h>

/* =========================================================================
 * Platform selection — uncomment ONE of the following
 * =========================================================================
 *
 * OPTION A: STM32CubeWL HAL + UTIL_SEQ (current code base, ported to Zephyr
 *            for thread/timer management; HAL remains ST's Radio API)
 *
 * OPTION B: Pure Zephyr subghz API (Zephyr 3.x stm32wl SUBGHZ driver)
 *
 * Set RF_HAL_BACKEND below to choose.
 */

/* #define RF_HAL_BACKEND_STM32CW   1   // STM32CubeWL HAL */
/* #define RF_HAL_BACKEND_ZEPHYR    1   // Zephyr subghz API */

/* Default: STM32CubeWL HAL (works as-is with your validated RF params) */
#define RF_HAL_BACKEND_STM32CW   1

#if defined(RF_HAL_BACKEND_ZEPHYR) && RF_HAL_BACKEND_ZEPHYR

/* ---------- Zephyr subghz backend (skeleton — adapt to Zephyr 3.x API) --------- */

#include <zephyr.h>
#include <subghz.h>       /* Zephyr SUBGHZ API: subghz_configure, subghz_transmit, subghz_receive */

typedef struct {
    /* Zephyr subghz_context — opaque, passed to callbacks */
    void *ctx;
} RadioContext_t;

typedef RadioContext_t Radio_t;

typedef struct {
    void (*TxDone)(void);
    void (*RxDone)(uint8_t *payload, uint16_t size, int16_t rssi, int8_t snr);
    void (*TxTimeout)(void);
    void (*RxTimeout)(void);
    void (*RxError)(void);
} RadioEvents_t;

/* Zephyr subghz returns a status; 0 = success */
#define RADIO_OK 0

static inline int Radio_Init(RadioEvents_t *events) {
    /* Zephyr: register callbacks, open device — adapt to your Zephyr version */
    return 0;
}

static inline void Radio_Sleep(void) {
    subghz_sleep();
}

static inline int Radio_SetFrequency(uint32_t freq_hz) {
    return subghz_set_frequency(freq_hz);
}

static inline int Radio_SetRxConfig(uint8_t modem, uint32_t bw, uint32_t datarate,
                                    uint32_t freq_hz, uint32_t afc_bw,
                                    uint8_t preamble_len, uint8_t fixed_len,
                                    bool fix_len_on, uint8_t payload_len,
                                    bool crc_on, uint8_t symb_seek, uint16_t seek_window,
                                    bool global_preamble, bool rx_on) {
    /* Map to Zephyr subghz_configure() — adapt parameters */
    struct subghz_config cfg = {0};
    cfg.frequency = freq_hz;
    cfg.bandwidth = bw;
    cfg.datarate = datarate;
    cfg.fdev = FSK_FDEV;   /* defined in parent scope */
    cfg.preamble_len = preamble_len;
    cfg.crc_on = crc_on;
    cfg.fixed_len = fixed_len_on;
    cfg.payload_len = payload_len > 0 ? payload_len : (RF_HEADER_SIZE + RF_MAX_PAYLOAD);
    return subghz_configure(&cfg);
}

static inline int Radio_SetTxConfig(uint8_t modem, uint8_t power,
                                    uint32_t fdev, uint32_t freq_hz,
                                    uint32_t datarate, uint32_t bandwidth,
                                    uint8_t preamble_len, uint8_t fixed_len,
                                    bool crc_on, uint8_t payload_len,
                                    uint16_t timeout_ms, uint16_t seek_window,
                                    bool global_preamble, uint16_t tx_timeout) {
    struct subghz_config cfg = {0};
    cfg.frequency = freq_hz;
    cfg.bandwidth = bandwidth;
    cfg.datarate = datarate;
    cfg.fdev = fdev;
    cfg.fixed_len = fixed_len;
    cfg.crc_on = crc_on;
    cfg.power = power;    /* dBm */
    cfg.preamble_len = preamble_len;
    cfg.payload_len = payload_len > 0 ? payload_len : (RF_HEADER_SIZE + RF_MAX_PAYLOAD);
    return subghz_configure(&cfg);
}

static inline int Radio_SetMaxPayloadLength(uint8_t modem, uint8_t max_len) {
    /* Zephyr: set max payload length in config — no separate call usually */
    return 0;
}

static inline int Radio_Send(const uint8_t *buffer, uint8_t size) {
    return subghz_transmit(buffer, size);
}

static inline int Radio_Rx(uint16_t timeout_ms) {
    return subghz_receive(timeout_ms);
}

#else /* RF_HAL_BACKEND_STM32CW — STM32CubeWL HAL */

/*
 * Include the STM32CubeWL HAL headers.
 * In a Zephyr project, these are available if you've added the
 * STM32CubeWL firmware package to your project and included its
 * inc/ and src/ directories.
 *
 * Typical inc paths (adjust to your project layout):
 *   - "STM32WLxx_HAL_Driver/Inc/stm32wlxx_hal.h"
 *   - "STM32WLxx_HAL_Driver/Inc/stm32wlxx_hal_gpio.h"
 *   - "STM32WLxx_HAL_Driver/Inc/stm32wlxx_hal_rcc.h"
 *   - "STM32CubeWL/RF/radio.h"
 *   - "STM32CubeWL/utilities/stm32_seq.h"
 *   - "STM32CubeWL/utilities/stm32_timer.h"
 */

#include <stdint.h>

/* ST RF HAL types (re-declared to avoid header dependency issues in this file).
 * In production, #include "radio.h" from STM32CubeWL instead. */

typedef enum {
    MODEM_FSK = 0,
    MODEM_OOK  = 1
} RadioModem_t;

typedef struct {
    void (*TxDone)(void);
    void (*RxDone)(uint8_t *payload, uint16_t size, int16_t rssi, int8_t snr);
    void (*TxTimeout)(void);
    void (*RxTimeout)(void);
    void (*RxError)(void);
} RadioEvents_t;

/* Opaque Radio handle — in production, this is the HAL's Radio_t */
typedef struct Radio Radio_t;

/* Radio API — these map 1:1 to STM32CubeWL's Radio_* functions */
extern Radio_t Radio;   /* instantiated in HAL init code (main.c or board init) */

static inline void Radio_Sleep(void)    { Radio.Sleep(); }
static inline void Radio_SetChannel(uint32_t freq_hz) { Radio.SetChannel(freq_hz); }
static inline void Radio_SetRxConfig(RadioModem_t modem, uint32_t bw,
                                     uint32_t datarate, uint32_t freq_hz,
                                     uint32_t afc_bw, uint16_t preamble_len,
                                     uint16_t sym_seek, uint8_t fix_len,
                                     uint8_t fix_len_on, bool crc_on,
                                     uint8_t payload_len, uint8_t max_payload,
                                     bool global_preamble, bool rx_on) {
    Radio.SetRxConfig(modem, bw, datarate, 0, afc_bw, preamble_len,
                      0, fix_len_on, 0, crc_on, 0, 0, false, true);
}
static inline void Radio_SetTxConfig(RadioModem_t modem, uint8_t power,
                                     uint32_t fdev, uint32_t freq_hz,
                                     uint32_t datarate, uint32_t bw,
                                     uint16_t preamble_len, uint8_t fix_len,
                                     bool fix_len_on, uint8_t payload_len,
                                     uint16_t tx_timeout, uint16_t seek_window,
                                     bool crc_on, uint8_t dummy2) {
    Radio.SetTxConfig(modem, power, fdev, 0, datarate, 0,
                      preamble_len, fix_len_on, true, 0, 0, 0, tx_timeout);
}
static inline void Radio_SetMaxPayloadLength(RadioModem_t modem, uint16_t max_len) {
    Radio.SetMaxPayloadLength(modem, max_len);
}
static inline void Radio_Send(const uint8_t *buffer, uint16_t size) {
    Radio.Send((uint8_t *)buffer, size);
}
static inline void Radio_Rx(uint16_t timeout_ms) {
    Radio.Rx(timeout_ms);
}
static inline void Radio_Init(RadioEvents_t *events) {
    Radio.Init(events);
}

#endif /* RF_HAL_BACKEND */

#endif /* RF_HALWRAPPER_H */
