/**
 * subghz_mavlink_bridge.c  —  Zephyr RTOS  Sub-GHz MAVLink Bridge
 * =====================================================================
 * Target : Nucleo-WL55JC1  (STM32WL55JC1, integrated SUBGHZ transceiver)
 * RF     : FSK  13.12 kbps  bidirectional  UART <-> RF  bridge
 * Zephyr : 3.x  – native k_thread + k_timer  +  STM32CubeWL HAL for RF
 *
 * Thread 1  radio_app_thread  (prio 2, stack 2048 B)
 *   Radio event FIFO dispatch + state machine (IDLE / TX / RX)
 *   Frame encoding (UART->RF)  and  decoding (RF->UART)
 *   Sequence tracking : duplicates, gaps, ordering
 *
 * Thread 2  uart_dma_thread  (prio 2, stack 2048 B)
 *   UART2 RX circular DMA producer  (IDLE + half-cplt + cplt callbacks)
 *   DMA buffer  ->  tx_ring  drain
 *   RX ring  ->  UART2 TX DMA  forward  (handled by rf_to_uart_thread)
 *
 * Thread 3  uart_to_rf_thread  (prio 2, stack 2048 B)
 *   Drain tx_ring  ->  build RF frame  ->  Radio_Send()
 *
 * Thread 4  rf_to_uart_thread  (prio 2, stack 2048 B)
 *   Drain rx_ring  ->  UART2 TX DMA  (so Python RX logger can capture)
 *
 * Thread 5  uart_recovery_thread  (prio 2, stack 2048 B)
 *   Restart UART2 RX DMA after error
 *
 * Zephyr timer  tx_retry_timer  (10 ms period)
 *   Deferred TX : wakes radio thread when radio becomes idle and data is queued
 *
 * All ring buffers + event FIFO : lock-free from IRQ context
 * (PRIMASK critical sections — identical to original CubeHAL code).
 *
 * ============================================================================
 * RF BACKEND — two options (select in rf_halwrapper.h)
 * ============================================================================
 * A) STM32CubeWL HAL  (RF_HAL_BACKEND_STM32CW = 1, default)
 *    Uses ST's Radio_* API (SetRxConfig/SetTxConfig/Send/Rx/Sleep/Init)
 *    from STM32CubeWL/RF/radio.h — identical to your current code.
 *    Zephyr provides threads/timer; the HAL drives the RF peripheral.
 *
 * B) Zephyr native SUBGHZ driver  (RF_HAL_BACKEND_ZEPHYR = 1)
 *    Uses Zephyr's subghz_configure()/subghz_transmit()/subghz_receive().
 *    Requires Zephyr 3.x + CONFIG_STM32WL_SUBGHZ=y.
 *    FSK parameter names differ; see rf_halwrapper.h for mapping.
 *
 * Both backends expose the same callbacks (TxDone/RxDone/TxTimeout/etc.)
 * so the rest of the bridge is backend-agnostic.
 */

#include <zephyr.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>

#include "subghz_mavlink_bridge.h"
#include "rf_halwrapper.h"

/* STM32CubeWL HAL headers (required by radio callbacks + UART DMA) */
#include "stm32wlxx_hal.h"   /* STM32WL HAL — USART, DMA, IRQ */
#include "radio.h"           /* ST RF HAL — Radio type, RadioEvents_t, Radio_* API */

/*
 * In a real Zephyr project these come from the STM32CubeWL firmware
 * package. See README / CMakeLists.txt for integration instructions.
 */

/* ============================================================================
 * Node ID configuration (per-board, overridden by Kconfig / device tree)
 * ============================================================================ */
#ifndef CONFIG_THIS_NODE_ID
#define CONFIG_THIS_NODE_ID   THIS_NODE_ID
#endif
#ifndef CONFIG_TARGET_NODE_ID
#define CONFIG_TARGET_NODE_ID TARGET_NODE_ID
#endif
#ifndef CONFIG_PEER_NODE_ID
#define CONFIG_PEER_NODE_ID   PEER_NODE_ID
#endif

#define THIS_NODE   CONFIG_THIS_NODE_ID
#define TARGET_NODE CONFIG_TARGET_NODE_ID
#define PEER_NODE   CONFIG_PEER_NODE_ID

/* ============================================================================
 * Thread / timer / semaphore handles  (.bss, statically allocated)
 * ============================================================================ */
#define APP_STACK_SIZE  2048
#define UART_STACK_SIZE 2048
#define FWD_STACK_SIZE  2048

static uint8_t  app_stack[APP_STACK_SIZE]   __aligned(8);
static uint8_t  uart_stack[UART_STACK_SIZE] __aligned(8);
static uint8_t  fwd_stack[FWD_STACK_SIZE]   __aligned(8);

static struct k_thread  app_thread;
static struct k_thread  uart_thread;
static struct k_thread  uart_to_rf_thread;
static struct k_thread  rf_to_uart_thread;
static struct k_thread  uart_recovery_thread;

static struct k_timer    tx_retry_timer;

static struct k_sem      radio_ev_sem;
static struct k_sem      uart_data_sem;
static struct k_sem      rx_fwd_sem;

/* ============================================================================
 * Runtime flags
 * ============================================================================ */
static volatile uint8_t uart_tx_busy         = 0;
static volatile uint8_t uart_recovery_pending = 0;
static volatile uint8_t tx_pending_request   = 0;

/* ============================================================================
 * Ring buffer utilities  (lock-free, PRIMASK critical section for IRQ safety)
 * ============================================================================ */

static inline uint32_t irq_enter(void) {
    uint32_t pm = __get_PRIMASK();
    __disable_irq();
    return pm;
}
static inline void irq_exit(uint32_t pm) {
    __set_PRIMASK(pm);
}

/* ---- TX ring  (UART RX  ->  RF TX) ---- */
static uint8_t  tx_ring[TX_RING_SIZE];
static volatile uint16_t tx_ring_head = 0;
static volatile uint16_t tx_ring_tail = 0;

static inline uint16_t tx_ring_count(void) {
    uint16_t h = tx_ring_head, t = tx_ring_tail;
    return (h >= t) ? (h - t) : (TX_RING_SIZE - t + h);
}
static inline uint16_t tx_ring_free(void) {
    return (TX_RING_SIZE - 1) - tx_ring_count();
}
static inline void tx_ring_push(uint8_t b) {
    if (tx_ring_free() > 0) {
        tx_ring[tx_ring_head] = b;
        tx_ring_head = (tx_ring_head + 1) % TX_RING_SIZE;
    }
}
static inline uint16_t tx_ring_pop(uint8_t *buf, uint16_t max) {
    uint16_t n = (tx_ring_count() < max) ? tx_ring_count() : max;
    for (uint16_t i = 0; i < n; i++)
        buf[i] = tx_ring[(tx_ring_tail + i) % TX_RING_SIZE];
    tx_ring_tail = (tx_ring_tail + n) % TX_RING_SIZE;
    return n;
}

/* ---- RX ring  (RF RX  ->  UART TX) ---- */
static uint8_t  rx_ring[RX_RING_SIZE];
static volatile uint16_t rx_ring_head = 0;
static volatile uint16_t rx_ring_tail = 0;

static inline uint16_t rx_ring_count(void) {
    uint16_t h = rx_ring_head, t = rx_ring_tail;
    return (h >= t) ? (h - t) : (RX_RING_SIZE - t + h);
}
static inline uint16_t rx_ring_free(void) {
    return (RX_RING_SIZE - 1) - rx_ring_count();
}
static inline uint16_t rx_ring_pop(uint8_t *buf, uint16_t max) {
    uint16_t n = (rx_ring_count() < max) ? rx_ring_count() : max;
    for (uint16_t i = 0; i < n; i++)
        buf[i] = rx_ring[(rx_ring_tail + i) % RX_RING_SIZE];
    rx_ring_tail = (rx_ring_tail + n) % RX_RING_SIZE;
    return n;
}
static inline void rx_ring_push(const uint8_t *buf, uint16_t n) {
    for (uint16_t i = 0; i < n && rx_ring_free() > 0; i++) {
        rx_ring[rx_ring_head] = buf[i];
        rx_ring_head = (rx_ring_head + 1) % RX_RING_SIZE;
    }
}

/* ============================================================================
 * Radio event FIFO  (8-slot circular queue)
 * ============================================================================ */
#define RF_EVT_Q_SIZE  8
static volatile uint8_t  evt_queue[RF_EVT_Q_SIZE];
static volatile uint8_t  evt_head = 0;
static volatile uint8_t  evt_tail = 0;

typedef enum {
    RF_EVT_NONE       = 0,
    RF_EVT_TX_DONE,
    RF_EVT_RX_DONE,
    RF_EVT_TX_TIMEOUT,
    RF_EVT_RX_TIMEOUT,
    RF_EVT_RX_ERROR
} RF_Event_t;

static void evt_post(RF_Event_t e) {
    uint32_t pm = irq_enter();
    uint8_t next = (evt_head + 1) % RF_EVT_Q_SIZE;
    if (next != evt_tail) {
        evt_queue[evt_head] = (uint8_t)e;
        evt_head = next;
    }
    irq_exit(pm);
    k_sem_give(&radio_ev_sem);
}
static RF_Event_t evt_take(void) {
    RF_Event_t e = RF_EVT_NONE;
    uint32_t pm = irq_enter();
    if (evt_head != evt_tail) {
        e = (RF_Event_t)evt_queue[evt_tail];
        evt_tail = (evt_tail + 1) % RF_EVT_Q_SIZE;
    }
    irq_exit(pm);
    return e;
}
static bool evt_pending(void) {
    uint32_t pm = irq_enter();
    bool r = evt_head != evt_tail;
    irq_exit(pm);
    return r;
}

/* ============================================================================
 * Radio state
 * ============================================================================ */
typedef enum { RF_IDLE, RF_TX, RF_RX } rf_state_t;
static volatile rf_state_t rf_state = RF_IDLE;

/* TX sequence number */
static volatile uint16_t tx_seq = 0;

/* ISR -> thread RX staging buffer (one packet max) */
static uint8_t  isr_rx_buf[RF_MAX_FRAME];
static volatile uint16_t isr_rx_len = 0;

/* ============================================================================
 * Diagnostics
 * ============================================================================ */
static subghz_diag_t diag = {0};

const subghz_diag_t *subghz_diag(void) {
    return &diag;
}

/* ============================================================================
 * Radio callbacks  (called from ISR context — ST RF HAL ISR)
 * ============================================================================ */
static void cb_tx_done(void) {
    evt_post(RF_EVT_TX_DONE);
}
static void cb_rx_done(uint8_t *payload, uint16_t size, int16_t rssi, int8_t snr) {
    ARG_UNUSED(rssi); ARG_UNUSED(snr);
    if (size > sizeof(isr_rx_buf)) { evt_post(RF_EVT_RX_ERROR); return; }
    memcpy(isr_rx_buf, payload, size);
    isr_rx_len = size;
    __DMB();
    evt_post(RF_EVT_RX_DONE);
}
static void cb_tx_timeout(void) { evt_post(RF_EVT_TX_TIMEOUT); }
static void cb_rx_timeout(void) { evt_post(RF_EVT_RX_TIMEOUT); }
static void cb_rx_error(void)   { evt_post(RF_EVT_RX_ERROR); }

/* ============================================================================
 * RF configuration  (mirrors original CubeHAL Radio_* calls)
 * ============================================================================ */
static void radio_go_rx(void) {
    Radio_Sleep();
    Radio_SetChannel(RF_FREQUENCY);
    Radio_SetRxConfig(MODEM_FSK, FSK_BANDWIDTH, FSK_DATARATE, RF_FREQUENCY,
                      FSK_AFC_BANDWIDTH, FSK_PREAMBLE_LENGTH,
                      0, 0, 1, 1, 0, 0, 1, 1);
    Radio_SetMaxPayloadLength(MODEM_FSK, RF_HEADER_SIZE + RF_MAX_PAYLOAD);
    rf_state = RF_RX;
    Radio_Rx(RX_TIMEOUT_MS);
}
static void radio_configure_tx(void) {
    Radio_Sleep();
    Radio_SetChannel(RF_FREQUENCY);
    Radio_SetTxConfig(MODEM_FSK, TX_OUTPUT_POWER, FSK_FDEV, RF_FREQUENCY,
                      FSK_DATARATE, FSK_BANDWIDTH, FSK_PREAMBLE_LENGTH,
                      1, 1, 0, TX_TIMEOUT_MS, 0, 0, TX_TIMEOUT_MS);
    Radio_SetMaxPayloadLength(MODEM_FSK, RF_HEADER_SIZE + RF_MAX_PAYLOAD);
}

/* ============================================================================
 * Frame format
 * ============================================================================
 * RF wire frame :
 *   [0] sync1=0xAA  [1] sync2=0x55
 *   [2] src_node     [3] dst_node  (0xFF=broadcast)
 *   [4] msg_type=0x01             [5] payload_len=N
 *   [6] seq_LSB      [7] seq_MSB
 *   [8..8+N-1]  payload
 * Total = 8 + N  bytes
 */
static int rf_decode(const uint8_t *buf, uint16_t size,
                     const uint8_t **pay, uint8_t *plen, uint16_t *seq) {
    if (size < RF_HEADER_SIZE) return 0;
    if (buf[0] != SYNC_WORD_1 || buf[1] != SYNC_WORD_2) return 0;
    if (buf[2] != PEER_NODE) return 0;
    if (buf[3] != THIS_NODE && buf[3] != 0xFF) return 0;
    if (buf[4] != MSG_TYPE_DATA) return 0;
    uint8_t len = buf[5];
    if (len > RF_MAX_PAYLOAD) return 0;
    if (size != RF_HEADER_SIZE + len) return 0;
    *seq     = buf[6] | ((uint16_t)buf[7] << 8);
    *plen    = len;
    *pay     = &buf[RF_HEADER_SIZE];
    return 1;
}

/* ============================================================================
 * RX packet processing  (sequence tracking, dedup, rx_ring push)
 * ============================================================================ */
static uint16_t last_rx_seq = 0;
static uint8_t  have_rx_seq = 0;

static void process_rx_pkt(void) {
    const uint8_t *pay;
    uint8_t        len;
    uint16_t       seq;

    if (!rf_decode(isr_rx_buf, isr_rx_len, &pay, &len, &seq)) {
        diag.invalid_frame_count++;
        return;
    }
    /* ---- sequence tracking (identical to original CubeHAL logic) ---- */
    if (have_rx_seq) {
        uint16_t delta = seq - last_rx_seq;
        if (delta == 0) { diag.rx_duplicate_count++; return; }
        if (delta >= 0x8000) { diag.rx_duplicate_count++; return; }  /* old/duplicate */
        if (delta > 1)      { diag.rx_sequence_loss += (delta - 1); }
    }
    /* ---- push payload to rx_ring (RF -> UART path) ---- */
    uint16_t free = rx_ring_free();
    uint16_t copy = (len < free) ? len : free;
    if (copy < len) diag.rx_ring_overflow++;
    rx_ring_push(pay, copy);
    last_rx_seq = seq;
    have_rx_seq = 1;
    diag.rx_frame_count++;
    if (copy > 0) k_sem_give(&rx_fwd_sem);
}

/* ============================================================================
 * Thread 1 : radio_app_thread  — event dispatch + state machine
 * ============================================================================ */
static void radio_app_thread_fn(void *a, void *b, void *c) {
    ARG_UNUSED(a); ARG_UNUSED(b); ARG_UNUSED(c);
    while (true) {
        k_sem_take(&radio_ev_sem, K_FOREVER);
        RF_Event_t ev = evt_take();
        if (ev == RF_EVT_NONE) continue;

        bool is_tx = (ev == RF_EVT_TX_DONE || ev == RF_EVT_TX_TIMEOUT);
        bool is_rx = (ev == RF_EVT_RX_DONE || ev == RF_EVT_RX_TIMEOUT ||
                      ev == RF_EVT_RX_ERROR);

        if (is_tx && rf_state != RF_TX) { diag.radio_event_overrun++; }
        else if (is_rx && rf_state != RF_RX) { diag.radio_event_overrun++; }
        else {
            switch (ev) {
            case RF_EVT_RX_DONE:
                process_rx_pkt();
                rf_state = RF_IDLE;
                if (tx_ring_count() > 0) k_thread_wakeup(&app_thread);
                else radio_go_rx();
                break;
            case RF_EVT_TX_DONE:
                rf_state = RF_IDLE;
                if (tx_ring_count() > 0) k_thread_wakeup(&app_thread);
                else radio_go_rx();
                break;
            case RF_EVT_TX_TIMEOUT:
                diag.tx_timeout_count++;
                rf_state = RF_IDLE;
                if (tx_ring_count() > 0) k_thread_wakeup(&app_thread);
                else radio_go_rx();
                break;
            case RF_EVT_RX_TIMEOUT:
                rf_state = RF_IDLE;
                radio_go_rx();
                break;
            case RF_EVT_RX_ERROR:
                diag.rx_error_count++;
                rf_state = RF_IDLE;
                radio_go_rx();
                break;
            default: break;
            }
        }
        if (evt_pending()) k_sem_give(&radio_ev_sem);
    }
}

/* ============================================================================
 * Zephyr timer  — TX retry / defer wakeup  (10 ms period)
 * ============================================================================ */
static void tx_retry_timer_fn(struct k_timer *t) {
    ARG_UNUSED(t);
    if (rf_state == RF_IDLE && tx_ring_count() > 0)
        k_thread_wakeup(&app_thread);
}

/* ============================================================================
 * UART2 handle  (provided by STM32CubeWL HAL init)
 * ============================================================================ */
extern UART_HandleTypeDef huart2;

/* UART2 RX circular DMA buffer */
static uint8_t  uart_dma_buf[UART_DMA_BUF_SIZE];
static volatile uint32_t dma_wrap = 0;
static volatile uint32_t dma_read = 0;

/* ---- Start / restart UART2 RX DMA ---- */
void uart_rf_start_dma_rx(void) {
    dma_wrap  = 0;
    dma_read  = 0;
    uart_recovery_pending = 0;
    __HAL_UART_ABORT_RECEIVE(&huart2);
    if (HAL_UART_Receive_DMA(&huart2, uart_dma_buf, UART_DMA_BUF_SIZE) != HAL_OK) {
        uart_recovery_pending = 1;
        return;
    }
    __HAL_UART_CLEAR_IDLEFLAG(&huart2);
    __HAL_UART_ENABLE_IT(&huart2, UART_IT_IDLE);
}

/* ---- DMA producer position (accounting for buffer wrap) ---- */
static uint32_t dma_producer_total(void) {
    uint32_t w_a, w_b, rem, pos;
    do {
        w_a  = dma_wrap;
        rem  = (uint32_t)__HAL_DMA_GET_COUNTER(huart2.hdmarx);
        w_b  = dma_wrap;
    } while (w_a != w_b);
    if (rem > UART_DMA_BUF_SIZE) rem = UART_DMA_BUF_SIZE;
    pos = (UART_DMA_BUF_SIZE - rem) % UART_DMA_BUF_SIZE;
    return (w_a * UART_DMA_BUF_SIZE) + pos;
}

/* ============================================================================
 * Thread 2 : uart_dma_thread  — drain UART DMA buffer into tx_ring
 * ============================================================================ */
static void uart_dma_thread_fn(void *a, void *b, void *c) {
    ARG_UNUSED(a); ARG_UNUSED(b); ARG_UNUSED(c);
    while (true) {
        k_sem_take(&uart_data_sem, K_FOREVER);
        if (huart2.hdmarx == NULL) continue;

        uint32_t prod  = dma_producer_total();
        uint32_t avail = prod - dma_read;

        /* DMA overrun detection */
        if (avail > UART_DMA_BUF_SIZE) {
            diag.uart_dma_overrun++;
            dma_read = prod - UART_DMA_BUF_SIZE;
            avail    = UART_DMA_BUF_SIZE;
        }
        /* Copy bytes from DMA buffer to tx_ring */
        while (dma_read < prod) {
            uint16_t idx = (uint16_t)(dma_read % UART_DMA_BUF_SIZE);
            tx_ring_push(uart_dma_buf[idx]);   /* silently drops on full */
            dma_read++;
        }
        if (tx_ring_count() > 0) k_thread_wakeup(&app_thread);
    }
}

/* ============================================================================
 * UART HAL callbacks  (IRQ context → give semaphore to thread)
 * ============================================================================ */
void HAL_UART_RxHalfCpltCallback(UART_HandleTypeDef *huart) {
    if (huart->Instance == USART2) k_sem_give(&uart_data_sem);
}
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart) {
    if (huart->Instance == USART2) {
        dma_wrap++;            /* one full circular buffer completed */
        k_sem_give(&uart_data_sem);
    }
}
void HAL_UART_ErrorCallback(UART_HandleTypeDef *huart) {
    if (huart->Instance == USART2) {
        uart_recovery_pending = 1;
        k_sem_give(&uart_data_sem);
    }
}
void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart) {
    if (huart->Instance == USART2) {
        uart_tx_busy = 0;
        if (rx_ring_count() > 0) k_sem_give(&rx_fwd_sem);
    }
}

/* Call from USART2 IRQ handler when IDLE flag detected */
void uart_rf_idle_check_from_irq(void) {
    if (__HAL_UART_GET_FLAG(&huart2, UART_FLAG_IDLE) != RESET) {
        __HAL_UART_CLEAR_IDLEFLAG(&huart2);
        k_sem_give(&uart_data_sem);
    }
}

/* ============================================================================
 * Thread 3 : uart_to_rf_thread  — build RF frame from tx_ring, send
 * ============================================================================ */
static void uart_to_rf_thread_fn(void *a, void *b, void *c) {
    ARG_UNUSED(a); ARG_UNUSED(b); ARG_UNUSED(c);
    while (true) {
        k_sem_take(&uart_data_sem, K_MSEC(5));

        if (rf_state != RF_IDLE) { tx_pending_request = 1; continue; }
        uint16_t cnt = tx_ring_count();
        if (cnt == 0) { tx_pending_request = 0; continue; }
        if (tx_pending_request) {
            if (rf_state == RF_IDLE) tx_pending_request = 0;
            else continue;
        }
        if (tx_pending_request) continue;

        uint16_t payload_len = (cnt > RF_MAX_PAYLOAD) ? RF_MAX_PAYLOAD : cnt;
        uint8_t  rf_frame[RF_MAX_FRAME];

        rf_frame[0] = SYNC_WORD_1;
        rf_frame[1] = SYNC_WORD_2;
        rf_frame[2] = THIS_NODE;
        rf_frame[3] = TARGET_NODE;
        rf_frame[4] = MSG_TYPE_DATA;
        rf_frame[5] = (uint8_t)payload_len;
        rf_frame[6] = (uint8_t)(tx_seq & 0xFFU);
        rf_frame[7] = (uint8_t)(tx_seq >> 8U);

        uint16_t copied = tx_ring_pop(&rf_frame[RF_HEADER_SIZE], payload_len);
        if (copied < payload_len) {
            payload_len = copied;
            rf_frame[5] = (uint8_t)payload_len;
        }

        tx_seq++;
        diag.tx_frame_count++;

        radio_configure_tx();
        rf_state = RF_TX;
        Radio_Send(rf_frame, RF_HEADER_SIZE + payload_len);
    }
}

/* ============================================================================
 * Thread 4 : rf_to_uart_thread  — drain rx_ring to UART2 TX DMA
 * ============================================================================ */
static void rf_to_uart_thread_fn(void *a, void *b, void *c) {
    ARG_UNUSED(a); ARG_UNUSED(b); ARG_UNUSED(c);
    while (true) {
        k_sem_take(&rx_fwd_sem, K_FOREVER);
        if (uart_tx_busy) continue;
        uint16_t cnt = rx_ring_count();
        if (cnt == 0) continue;
        uint16_t chunk = (cnt > RF_MAX_PAYLOAD) ? RF_MAX_PAYLOAD : cnt;
        uint8_t  buf[RF_MAX_PAYLOAD];
        rx_ring_pop(buf, chunk);
        if (HAL_UART_Transmit_DMA(&huart2, buf, chunk) == HAL_OK)
            uart_tx_busy = 1;
    }
}

/* ============================================================================
 * Thread 5 : uart_recovery_thread  — restart DMA RX after error
 * ============================================================================ */
static void uart_recovery_thread_fn(void *a, void *b, void *c) {
    ARG_UNUSED(a); ARG_UNUSED(b); ARG_UNUSED(c);
    while (true) {
        k_sem_take(&uart_data_sem, K_FOREVER);
        if (uart_recovery_pending) {
            uart_tx_busy = 0;
            uart_rf_start_dma_rx();
        }
    }
}

/* ============================================================================
 * Public API
 * ============================================================================ */
void subghz_tx_byte(uint8_t byte) {
    tx_ring_push(byte);
}
bool subghz_tx_frame(const uint8_t *frame, uint16_t len) {
    for (uint16_t i = 0; i < len; i++)
        if (tx_ring_free() == 0) return false;
        else tx_ring_push(frame[i]);
    return true;
}
bool subghz_rx_avail(void) {
    return rx_ring_count() > 0;
}
uint16_t subghz_rx_read(uint8_t *buf, uint16_t max) {
    return rx_ring_pop(buf, max);
}

/* ============================================================================
 * subghz_bridge_init()  — call once from main()
 * ============================================================================ */
void subghz_bridge_init(void) {
    /* Zero all state */
    memset(evt_queue,    0, sizeof(evt_queue));
    memset(isr_rx_buf,   0, sizeof(isr_rx_buf));
    memset(tx_ring,      0, sizeof(tx_ring));
    memset(rx_ring,      0, sizeof(rx_ring));
    memset(&diag,        0, sizeof(diag));

    evt_head       = 0;
    evt_tail       = 0;
    rf_state       = RF_IDLE;
    tx_seq         = 0;
    last_rx_seq    = 0;
    have_rx_seq    = 0;
    tx_ring_head   = 0;
    tx_ring_tail   = 0;
    rx_ring_head   = 0;
    rx_ring_tail   = 0;
    tx_pending_request   = 0;
    uart_tx_busy          = 0;
    uart_recovery_pending = 0;
    isr_rx_len            = 0;
    dma_wrap              = 0;
    dma_read              = 0;

    /* Semaphores */
    k_sem_init(&radio_ev_sem,  0, 1);
    k_sem_init(&uart_data_sem, 0, 1);
    k_sem_init(&rx_fwd_sem,    0, 1);

    /* TX retry timer */
    k_timer_init(&tx_retry_timer, tx_retry_timer_fn, NULL);
    k_timer_start(&tx_retry_timer,
                  K_MSEC(TX_RETRY_PERIOD_MS),
                  K_MSEC(TX_RETRY_PERIOD_MS));

    /* Register radio callbacks (ST RF HAL) */
    RadioEvents.TxDone      = cb_tx_done;
    RadioEvents.RxDone      = cb_rx_done;
    RadioEvents.TxTimeout   = cb_tx_timeout;
    RadioEvents.RxTimeout   = cb_rx_timeout;
    RadioEvents.RxError     = cb_rx_error;

    /* Initialize Radio peripheral */
    Radio_Init(&RadioEvents);

    /* Start UART2 RX DMA */
    uart_rf_start_dma_rx();

    /* Enter RX mode */
    radio_go_rx();

    /* Create Zephyr threads */
    k_thread_create(&app_thread,
                    app_stack, sizeof(app_stack),
                    radio_app_thread_fn, NULL, NULL, NULL,
                    2, 0, K_NO_WAIT);

    k_thread_create(&uart_thread,
                    uart_stack, sizeof(uart_stack),
                    uart_dma_thread_fn, NULL, NULL, NULL,
                    2, 0, K_NO_WAIT);

    k_thread_create(&uart_to_rf_thread,
                    uart_stack, sizeof(uart_stack),
                    uart_to_rf_thread_fn, NULL, NULL, NULL,
                    2, 0, K_NO_WAIT);

    k_thread_create(&rf_to_uart_thread,
                    fwd_stack, sizeof(fwd_stack),
                    rf_to_uart_thread_fn, NULL, NULL, NULL,
                    2, 0, K_NO_WAIT);

    k_thread_create(&uart_recovery_thread,
                    fwd_stack, sizeof(fwd_stack),
                    uart_recovery_thread_fn, NULL, NULL, NULL,
                    2, 0, K_NO_WAIT);

    printk("Sub-GHz bridge init: Node 0x%02X -> 0x%02X | %d bps @ %u Hz | TX %d dBm\n",
           THIS_NODE, TARGET_NODE, FSK_DATARATE, RF_FREQUENCY, TX_OUTPUT_POWER);
}
