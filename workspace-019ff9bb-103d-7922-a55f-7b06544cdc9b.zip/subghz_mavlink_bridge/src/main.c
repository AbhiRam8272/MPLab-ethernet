/**
 * main.c — Zephyr entry point for Sub-GHz MAVLink Bridge
 * =========================================================
 * Nucleo-WL55JC1 (STM32WL55JC1)
 *
 * Responsibilities:
 *   1. Include STM32CubeWL HAL headers (stm32wlxx_hal.h, radio.h)
 *   2. Declare extern handles (huart2, RadioEvents)
 *   3. Call subghz_bridge_init() to start the bridge
 *   4. Start optional MAVLink TX generator (bench-test mode)
 *   5. Start optional RX forwarder (RF→UART for Python logger capture)
 *
 * The bridge core (threads, rings, radio state machine) lives in
 * subghz_mavlink_bridge.c. This file is just the entry point.
 */

#include <zephyr.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>

#include "stm32wlxx_hal.h"   /* STM32WL HAL — USART, DMA, IRQ, clocks */
#include "radio.h"           /* ST RF HAL — Radio type, RadioEvents_t, Radio_* API */
#include "stm32_seq.h"       /* UTIL_SEQ (optional, only if HAL scheduler used) */
#include "stm32_timer.h"    /* UTIL_TIMER (optional) */

/* Bridge API */
#include "subghz_mavlink_bridge.h"

/*
 * Extern handles — defined in the STM32CubeWL HAL init code.
 * In a Zephyr project, these come from the board init or from the
 * STM32CubeWL firmware package's MX_*_Init() functions.
 */
extern UART_HandleTypeDef huart2;
extern RadioEvents_t      RadioEvents;

/*
 * Thread stacks for MAVLink utility tasks (bench-test mode).
 * The bridge core threads (radio, uart, forward) are in the bridge module.
 */
#define UTIL_STACK_SIZE  2048

/*
 * MAVLink TX generator — synthetic frame producer at 13.12 kbps.
 * Used for bench-testing without a real flight controller.
 * Disable CONFIG_MAVLINK_GENERATOR_ENABLE to use only the UART RX path.
 */
#ifdef CONFIG_MAVLINK_GENERATOR_ENABLE

static struct k_thread  mav_tx_thread;
static uint8_t          mav_tx_stack[UTIL_STACK_SIZE] __aligned(8);

/*
 * Synthetic MAVLink2 frame generator.
 * Generates frames mimicking a flight controller at 13.12 kbps.
 * Alternating frame types: HEARTBEAT (21 B), ATTITUDE (40 B), SYS_STATUS (43 B).
 *
 * Real implementation: replace with MAVLink library encoding + UART RX→RF path.
 */
static void mavlink_tx_generator(void *a, void *b, void *c) {
    ARG_UNUSED(a); ARG_UNUSED(b); ARG_UNUSED(c);

    const uint32_t bps          = 13120U;
    const uint16_t avg_frame    = 35;
    const uint32_t frame_ms     = (avg_frame * 8 * 1000) / bps;  /* ≈ 21 ms */

    uint16_t seq      = 0;
    uint32_t frame_n  = 0;

    while (true) {
        /* Alternate frame types to match real FC stream pattern */
        uint8_t lane = frame_n % 4;
        uint8_t frame[43];
        uint16_t flen;

        if (lane == 0) {
            /* HEARTBEAT: 9-byte payload → 21-byte wire frame */
            frame[0]  = 0xFD;  frame[1] = 9;
            frame[2]  = 0x00;  frame[3] = 0x00;
            frame[4]  = (uint8_t)(seq & 0xFF);   /* seq */
            frame[5]  = 0x01;  frame[6] = 0x01;  /* sysid=1, compid=1 */
            frame[7]  = 0x00;  frame[8] = 0x00;  frame[9] = 0x00;  /* msgid=0 */
            /* payload: 9 bytes */
            frame[10] = (uint8_t)(frame_n & 0xFF);
            frame[11] = 0x04;  frame[12] = 0x00;
            frame[13] = 0x00;  frame[14] = 0x00;
            frame[15] = 0x02;  frame[16] = 0x03;
            frame[17] = 0x81;  frame[18] = 0x04;
            frame[19] = 0x03;
            /* CRC (placeholder — use real MAVLink X.25 CRC in production) */
            frame[20] = 0x03;  frame[21] = 0x9f;
            flen = 22;
        } else if (lane <= 2) {
            /* ATTITUDE / GLOBAL_POS: 28-byte payload → 40-byte frame */
            frame[0]  = 0xFD;  frame[1] = 28;
            frame[2]  = 0x00;  frame[3] = 0x00;
            frame[4]  = (uint8_t)(seq & 0xFF);
            frame[5]  = 0x01;  frame[6] = 0x01;
            frame[7]  = 0x1E;  frame[8] = 0x00;  frame[9] = 0x00;  /* msgid=30 */
            for (int i = 0; i < 28; i++)
                frame[10 + i] = (uint8_t)((frame_n + i) & 0xFF);
            frame[38] = 0x3c;  frame[39] = 0x1e;
            flen = 40;
        } else {
            /* SYS_STATUS: 31-byte payload → 43-byte frame */
            frame[0]  = 0xFD;  frame[1] = 31;
            frame[2]  = 0x00;  frame[3] = 0x00;
            frame[4]  = (uint8_t)(seq & 0xFF);
            frame[5]  = 0x01;  frame[6] = 0x01;
            frame[7]  = 0x01;  frame[8] = 0x00;  frame[9] = 0x00;  /* msgid=1 */
            for (int i = 0; i < 31; i++)
                frame[10 + i] = (uint8_t)((frame_n * 3 + i) & 0xFF);
            frame[42] = 0xb0;
            flen = 43;
        }

        subghz_tx_frame(frame, flen);
        seq++;
        frame_n++;

        k_msleep(frame_ms);
    }
}
#endif /* CONFIG_MAVLINK_GENERATOR_ENABLE */

/*
 * RF→UART forwarder — forwards received RF data to UART2 TX.
 * This allows the Python RX logger on the ground station PC to capture
 * the MAVLink stream via the RX Nucleo's UART.
 */
static struct k_thread  rx_fwd_thread;
static uint8_t          rx_fwd_stack[UTIL_STACK_SIZE] __aligned(8);

static void rf_to_uart_forwarder(void *a, void *b, void *c) {
    ARG_UNUSED(a); ARG_UNUSED(b); ARG_UNUSED(c);

    uint8_t buf[RF_MAX_PAYLOAD];
    while (true) {
        if (subghz_rx_avail()) {
            uint16_t n = subghz_rx_read(buf, sizeof(buf));
            if (n > 0) {
                /*
                 * Use HAL_UART_Transmit_DMA to forward to UART2.
                 * In a pure-Zephyr UART API port, use uart_tx() with callback.
                 */
                if (HAL_UART_Transmit_DMA(&huart2, buf, n) == HAL_OK) {
                    /* Wait for TX complete before forwarding more */
                    while (uart_tx_busy) { k_msleep(1); }
                }
            }
        }
        k_msleep(1);
    }
}

/* ============================================================================
 * Zephyr main() — system init + thread creation
 * ============================================================================ */
void main(void) {
    printk("\n=== Sub-GHz MAVLink Bridge — Zephyr on Nucleo-WL55JC1 ===\n");
    printk("RF: FSK %d bps @ %u Hz | TX power: %d dBm\n",
           FSK_DATARATE, RF_FREQUENCY, TX_OUTPUT_POWER);
    printk("Node ID: 0x%02X (this) → 0x%02X (target), peer: 0x%02X\n",
           THIS_NODE, TARGET_NODE, PEER_NODE);

    /*
     * STM32 HAL system initialization.
     *
     * In practice this requires:
     *   HAL_Init()
     *   SystemClock_Config()  → HSI, PLL → 48 MHz core / 32 MHz RF
     *   MX_USART2_UART_Init() → 115200, 2 stop bits, no parity
     *   MX_DMA_Init()         → DMA2 streams for USART2 RX/TX
     *   MX_GPIO_Init()        → LED, SWD, any RF switch GPIO
     *   Radio_Init(&RadioEvents) → ST RF HAL
     *
     * These are typically generated by STM32CubeMX and reside in the
     * STM32CubeWL project's main.c. In a Zephyr project, include the
     * STM32CubeWL init code via a board file or directly here.
     *
     * Zephyr's stm32wl platform handles most of the peripheral init
     * via device tree, but the ST RF HAL (Radio) requires explicit
     * STM32CubeWL initialization. The simplest path:
     *   - Include STM32CubeWL's system init in your board's init
     *   - Or call the MX_* functions directly from main() before
     *     subghz_bridge_init()
     */
    /* Placeholder — replace with actual STM32CubeWL init sequence */
    hal_system_init_stm32cw();

    /*
     * Initialize the bridge — creates all threads, timer, rings, radio.
     */
    subghz_bridge_init();

    /*
     * Optional: start MAVLink TX generator (bench-test mode).
     * Without this, the TX path is fed by UART2 RX from the flight controller.
     */
#ifdef CONFIG_MAVLINK_GENERATOR_ENABLE
    k_thread_create(&mav_tx_thread,
                    mav_tx_stack, sizeof(mav_tx_stack),
                    mavlink_tx_generator, NULL, NULL, NULL,
                    2, 0, K_NO_WAIT);
    printk("MAVLink TX generator started (bench-test mode)\n");
#endif

    /*
     * Optional: start RF→UART forwarder (so Python RX logger can capture).
     */
    k_thread_create(&rx_fwd_thread,
                    rx_fwd_stack, sizeof(rx_fwd_stack),
                    rf_to_uart_forwarder, NULL, NULL, NULL,
                    2, 0, K_NO_WAIT);
    printk("RF→UART forwarder started (for Python logger capture)\n");

    printk("Bridge ready. Waiting for radio events...\n");

    /* Main thread idles — all work in sub-threads */
    while (true) {
        k_msleep(10000);
    }
}

/*
 * Placeholder for STM32CubeWL HAL system init.
 * In production, replace with the actual init sequence from your
 * STM32CubeMX-generated main.c / board support file.
 */
static void hal_system_init_stm32cw(void) {
    /*
     * Required sequence for STM32WL + ST RF HAL:
     *
     * 1. HAL_Init()             — init HAL lib, SysTick
     * 2. SystemClock_Config()   — HSI, PLL → 48 MHz HCLK, 32 MHz RFCLK
     * 3. MX_GPIO_Init()         — configure antenna switch LED, etc.
     * 4. MX_USART2_UART_Init()  — UART2: 115200, 2 stop, no parity
     * 5. MX_DMA_Init()          — DMA2: stream 4 (USART2_RX), stream 5 (USART2_TX)
     * 6. MX_ICACHE_Init()       — instruction cache (if applicable)
     * 7. Radio_Init(&RadioEvents) — ST RF HAL initialization
     *
     * In the STM32CubeWL project, these are auto-generated by CubeMX.
     * For Zephyr, either:
     *   a) Include the STM32CubeWL firmware package and call its init
     *   b) Use Zephyr's stm32wl platform (handles 1-5 via device tree)
     *      and add STM32CubeWL's Radio_Init() call manually
     *
     * For option (b), Zephyr's stm32wl platform already configures
     * the RCC, GPIO, and UART via device tree. You only need to add
     * the STM32CubeWL RF HAL init.
     */
    printk("[HAL init stub] Replace with actual STM32CubeWL init sequence.\n");
    printk("[HAL init stub] See README 'STM32CubeWL HAL integration' section.\n");
}
